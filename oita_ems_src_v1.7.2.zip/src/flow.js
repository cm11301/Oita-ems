// 大分県「傷病者の搬送及び受入れの実施基準」(令和7年4月改定) に準拠した問診フロー
// ※Ⅵ．搬送先選定フロー（実施基準本編 P17〜21）の図に基づき、公式フローの分岐構造をできるだけ忠実に再現している。
// 公式フローで複数の医療機関リストが同時に提示される箇所は、dataKeys に複数キーを入れて1画面にまとめて表示する。
export const FLOW = {
  start: {
    q: "傷病者の区分を選択してください",
    choices: [
      // hint：実施基準P2「傷病者の区分」・P4（●妊産褥婦の外傷等）の定義を原文に沿って表示
      { label: "疾病：成人一般（15歳以上）", next: "adult_arrest_q", hint: "「妊産褥婦」及び「小児」以外の者" },
      { label: "疾病：小児（15歳未満）", next: "peds_arrest_q", hint: "自宅（車中）分娩における新生児を除く（→妊産褥婦）" },
      { label: "疾病：妊産褥婦", next: "maternal_arrest_q", hint: "妊娠中～産後１ヶ月健診受診前の者。自宅（車中）分娩における新生児を含む" },
      { label: "外傷・熱傷・中毒", next: "trauma_arrest_q", hint: "妊産褥婦の外傷・熱傷・中毒もこちら" },
      { label: "精神疾患（身体合併症を含む）", next: "psych_q1" },
    ],
  },

  // ---------- 成人一般（P17フロー） ----------
  adult_arrest_q: {
    q: "心肺停止が明らかですか？",
    sub: "心肺停止が明らかな場合は、重症度判定を待たず直近の対応可能な救急医療機関等へ搬送を開始する",
    choices: [
      { label: "はい（心肺停止）", next: "r_arrest" },
      { label: "いいえ", next: "adult_vital" },
    ],
  },
  adult_vital: {
    type: "card",
    cardImage: "adult",
    title: "疾病観察カード【成人一般】",
    instruction: "カード原本の画像上で、該当する項目を直接タップしてください（緑=通常、青=青枠、赤=赤枠）",
    rows: [
      {
        id: "state",
        label: "状態",
        options: [
          {
            id: "state_normal",
            label: "歩行可能・不能（仰・側・腹・坐・その他）",
            tier: "normal",
            box: { x1: 31, y1: 14.79, x2: 77, y2: 17.18 },
          },
          { id: "state_collapse", label: "虚脱", tier: "red", box: { x1: 77, y1: 14.79, x2: 84.5, y2: 17.18 } },
        ],
      },
      {
        id: "face_color",
        label: "顔色",
        options: [
          { id: "face_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 17.18, x2: 40, y2: 19.49 } },
          { id: "face_yellow_flush", label: "黄・紅潮", tier: "normal", box: { x1: 40, y1: 17.18, x2: 53.5, y2: 19.49 } },
          { id: "face_earthy", label: "土気色", tier: "normal", box: { x1: 53.5, y1: 17.18, x2: 65.67, y2: 19.49 } },
          {
            id: "face_pale_cyanosis",
            label: "蒼白・チアノーゼ",
            tier: "red",
            box: { x1: 65.67, y1: 17.18, x2: 84.5, y2: 19.49 },
          },
        ],
      },
      {
        id: "expression",
        label: "表情",
        options: [
          { id: "expr_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 19.49, x2: 40, y2: 21.88 } },
          { id: "expr_excited", label: "興奮・不安・苦悶", tier: "normal", box: { x1: 40, y1: 19.49, x2: 65.56, y2: 21.88 } },
          { id: "expr_blank", label: "無表情・うつろ", tier: "red", box: { x1: 65.56, y1: 19.49, x2: 84.5, y2: 21.88 } },
        ],
      },
      {
        id: "vomit_incontinence",
        label: "嘔吐・失禁",
        options: [
          { id: "vi_none", label: "なし", tier: "normal", box: { x1: 31, y1: 21.88, x2: 40, y2: 24.28 } },
          { id: "vi_symptom", label: "嘔気・嘔吐・吐血・喀血", tier: "normal", box: { x1: 40, y1: 21.88, x2: 70.3, y2: 24.28 } },
          {
            id: "vi_incontinence",
            label: "失禁（大・小）",
            tier: "normal",
            box: { x1: 70.3, y1: 21.88, x2: 84.5, y2: 24.28 },
          },
        ],
      },
      {
        id: "skin",
        label: "皮膚体温等",
        options: [
          { id: "skin_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 24.28, x2: 40, y2: 26.67 } },
          {
            id: "skin_dry_etc",
            label: "乾燥・発熱・湿潤・発汗・浮腫",
            tier: "normal",
            box: { x1: 40, y1: 24.28, x2: 72.4, y2: 26.67 },
          },
          { id: "cold_sweat", label: "冷汗", tier: "red", box: { x1: 72.4, y1: 24.28, x2: 77.1, y2: 26.67 } },
          { id: "cold_feeling", label: "冷感", tier: "normal", box: { x1: 77.1, y1: 24.28, x2: 84.5, y2: 26.67 } },
        ],
      },
      {
        id: "eyelid_nail",
        label: "眼瞼結膜・爪床・四肢末梢",
        options: [
          { id: "en_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 26.67, x2: 40, y2: 33.76 } },
          {
            id: "en_pale_cyanosis",
            label: "蒼白・チアノーゼ",
            tier: "normal",
            box: { x1: 40, y1: 26.67, x2: 84.5, y2: 33.76 },
          },
        ],
      },
      {
        id: "consciousness",
        label: "意識",
        options: [
          { id: "clear", label: "清明", tier: "normal", box: { x1: 31.33, y1: 33.76, x2: 39.89, y2: 37.36 } },
          { id: "jcs1_10", label: "1・2・3・10", tier: "normal", box: { x1: 39.89, y1: 33.76, x2: 56.78, y2: 37.36 } },
          { id: "jcs20_30", label: "20・30", tier: "normal", box: { x1: 56.78, y1: 33.76, x2: 67.89, y2: 37.36 } },
          { id: "jcs100_300", label: "100・200・300", tier: "blue", box: { x1: 67.89, y1: 33.76, x2: 84, y2: 37.36 } },
        ],
      },
      {
        id: "consciousness_state",
        label: "意識（性状）",
        options: [
          { id: "air", label: "A自発性喪失・I便尿失禁・R不穏状態", tier: "normal", box: { x1: 31.33, y1: 37.36, x2: 71, y2: 39.66 } },
          { id: "progressing", label: "意識障害進行", tier: "blue", box: { x1: 71, y1: 37.36, x2: 84.11, y2: 39.66 } },
        ],
      },
      {
        id: "breath_state",
        label: "呼吸性状",
        options: [
          { id: "b_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 39.66, x2: 40, y2: 41.96 } },
          {
            id: "shallow_deep_wheeze",
            label: "浅・深・喘鳴",
            tier: "normal",
            box: { x1: 40, y1: 39.66, x2: 58.67, y2: 41.96 },
          },
          { id: "abnormal_breath", label: "異常（呼吸）", tier: "red", box: { x1: 58.67, y1: 39.66, x2: 82.33, y2: 41.96 } },
          { id: "insufficient_chest", label: "胸部挙上不十分", tier: "red", box: { x1: 47, y1: 41.96, x2: 62.56, y2: 44.45 } },
          { id: "no_breath", label: "感ぜず", tier: "red", box: { x1: 72.89, y1: 41.96, x2: 81.67, y2: 44.45 } },
        ],
      },
      {
        id: "resp_rate",
        label: "呼吸数",
        options: [
          { id: "rr_16_19", label: "16〜19回/分", tier: "normal", box: { x1: 31, y1: 44.45, x2: 40, y2: 49.24 } },
          {
            id: "rr_10_29",
            label: "10〜15回/分・20〜29回/分",
            tier: "normal",
            box: { x1: 40, y1: 44.45, x2: 70.22, y2: 49.24 },
          },
          {
            id: "rr_extreme",
            label: "10回/分未満・30回/分以上",
            tier: "blue",
            box: { x1: 71.33, y1: 44.45, x2: 83.78, y2: 49.24 },
          },
        ],
      },
      {
        id: "breath_sound",
        label: "呼吸音",
        options: [
          { id: "bs_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 49.24, x2: 40, y2: 51.54 } },
          { id: "bs_lr_none", label: "左右差（なし）", tier: "normal", box: { x1: 40, y1: 49.24, x2: 53.4, y2: 51.54 } },
          { id: "bs_lr_yes", label: "左右差（あり）", tier: "normal", box: { x1: 53.4, y1: 49.24, x2: 60.3, y2: 51.54 } },
          { id: "bs_rale", label: "乾性ラ音・湿性ラ音", tier: "normal", box: { x1: 60.3, y1: 49.24, x2: 84.5, y2: 51.54 } },
        ],
      },
      {
        id: "pulse_touch",
        label: "脈拍（総頸動脈）",
        options: [
          { id: "palpable", label: "整・不整（触知可）", tier: "normal", box: { x1: 31, y1: 51.6, x2: 74.67, y2: 56.4 } },
          { id: "not_palpable", label: "総頸触れず", tier: "red", box: { x1: 74.67, y1: 54, x2: 84.5, y2: 61.18 } },
        ],
      },
      {
        id: "pulse_rate",
        label: "脈拍数",
        options: [
          { id: "pr_50_100", label: "50〜100回/分", tier: "normal", box: { x1: 31, y1: 56.43, x2: 40, y2: 61.22 } },
          { id: "pr_101_119", label: "101〜119回/分", tier: "normal", box: { x1: 40, y1: 56.43, x2: 50.89, y2: 61.22 } },
          { id: "pr_below50", label: "50回/分未満", tier: "blue", box: { x1: 50.89, y1: 56.43, x2: 59.22, y2: 61.22 } },
          { id: "pr_above120", label: "120回/分以上", tier: "blue", box: { x1: 64.33, y1: 56.43, x2: 72.67, y2: 61.22 } },
        ],
      },
      {
        id: "pulse_lr",
        label: "脈拍（左右差）",
        options: [
          { id: "pulse_lr_none", label: "なし", tier: "normal", box: { x1: 31, y1: 61.22, x2: 39.89, y2: 63.52 } },
          { id: "pulse_lr_yes", label: "あり", tier: "normal", box: { x1: 39.89, y1: 61.22, x2: 73.44, y2: 63.52 } },
        ],
      },
      {
        id: "bp_measure",
        label: "血圧（測定値の左右差）",
        options: [
          { id: "bp_measure_na", label: "／（測定なし）", tier: "normal", box: { x1: 31, y1: 63.52, x2: 39.89, y2: 65.92 } },
          {
            id: "bp_measure_none",
            label: "左右差（なし）",
            tier: "normal",
            box: { x1: 39.89, y1: 63.52, x2: 59.67, y2: 65.92 },
          },
          {
            id: "bp_measure_yes",
            label: "左右差（あり）",
            tier: "normal",
            box: { x1: 59.67, y1: 63.52, x2: 73.44, y2: 65.92 },
          },
        ],
      },
      {
        id: "bp",
        label: "血圧",
        options: [
          { id: "bp_140_90", label: "収縮期140〜90mmHg", tier: "normal", box: { x1: 31, y1: 65.92, x2: 40, y2: 70.61 } },
          {
            id: "bp_141_199",
            label: "収縮期141〜199mmHg",
            tier: "normal",
            box: { x1: 40, y1: 65.92, x2: 58.33, y2: 70.61 },
          },
          { id: "bp_below90", label: "収縮期90mmHg未満", tier: "blue", box: { x1: 58.33, y1: 65.92, x2: 73.5, y2: 68.31 } },
          {
            id: "bp_above200",
            label: "収縮期200mmHg以上",
            tier: "normal",
            box: { x1: 58.33, y1: 68.31, x2: 73.5, y2: 70.61 },
          },
          { id: "bp_unmeasurable", label: "測定不能", tier: "normal", box: { x1: 73.5, y1: 63.52, x2: 84.5, y2: 73.01 } },
        ],
      },
      {
        id: "spo2",
        label: "SpO2",
        options: [
          { id: "spo2_93", label: "93%〜", tier: "normal", box: { x1: 31, y1: 70.61, x2: 40, y2: 73.01 } },
          { id: "spo2_90_92", label: "90〜92%", tier: "normal", box: { x1: 40, y1: 70.61, x2: 58.33, y2: 73.01 } },
          { id: "spo2_below90", label: "90%未満", tier: "blue", box: { x1: 58.33, y1: 70.61, x2: 82, y2: 73.01 } },
        ],
      },
      {
        id: "pupil_size",
        label: "瞳孔（大きさ）",
        options: [
          { id: "pupil_size_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 73.01, x2: 39.67, y2: 75.4 } },
          {
            id: "pupil_size_abnormal",
            label: "縮小（両側）・不同（左＞・右＞）",
            tier: "normal",
            box: { x1: 39.67, y1: 73.01, x2: 73.67, y2: 75.4 },
          },
          { id: "pupil_size_dilated", label: "散大", tier: "normal", box: { x1: 73.67, y1: 73.01, x2: 84.5, y2: 75.4 } },
        ],
      },
      {
        id: "pupil_reflex",
        label: "瞳孔（反射）",
        options: [
          { id: "pupil_reflex_normal", label: "正常", tier: "normal", box: { x1: 31, y1: 75.4, x2: 39.89, y2: 77.8 } },
          { id: "pupil_reflex_dull", label: "にぶい", tier: "normal", box: { x1: 39.89, y1: 75.4, x2: 63.56, y2: 77.8 } },
          { id: "pupil_reflex_none", label: "なし", tier: "normal", box: { x1: 63.56, y1: 75.4, x2: 84.5, y2: 77.8 } },
        ],
      },
      {
        id: "pupil_deviation",
        label: "瞳孔（偏視）",
        options: [
          { id: "pupil_dev_none", label: "なし", tier: "normal", box: { x1: 31, y1: 77.8, x2: 39.89, y2: 80.1 } },
          {
            id: "pupil_dev_yes",
            label: "右・左・上・下・右斜め・左斜め・共同偏視",
            tier: "normal",
            box: { x1: 39.89, y1: 77.8, x2: 84.5, y2: 80.1 },
          },
        ],
      },
      {
        id: "pupil_diameter",
        label: "瞳孔径（mm）",
        options: [
          { id: "pd_1_2", label: "1〜2mm", tier: "normal", box: { x1: 31.11, y1: 80.1, x2: 39.89, y2: 85.4 } },
          { id: "pd_3_4", label: "3〜4mm", tier: "normal", box: { x1: 39.89, y1: 80.1, x2: 53.44, y2: 85.4 } },
          { id: "pd_5_8", label: "5〜8mm", tier: "normal", box: { x1: 53.44, y1: 80.1, x2: 80.44, y2: 85.4 } },
        ],
      },
    ],
    onSevere: "r_vital_severe",
    onClear: "adult_local_q",
  },
  adult_local_q: {
    q: "主訴・局所状態は？",
    choices: [
      { label: "💓 急性冠症候群の疑い（胸痛・放散痛）", next: "r_ami" },
      { label: "🧠 脳卒中の疑い（片麻痺・言語障害・顔面神経麻痺）", next: "stroke_q" },
      { label: "その他の重症所見（急性腹症・呼吸器・婦人科のいずれか）", next: "adult_other_severe_check" },
      { label: "上記いずれも該当しない（軽症）", next: "adult_light_category_q" },
    ],
  },
  stroke_q: {
    q: "脳卒中疑い：発症からの時間は？",
    sub: "発症後3.5時間以内にt-PA対応医療機関へ搬送可能な場合はt-PA対応を優先。判断に迷う場合は最寄りの脳卒中対応医療機関に指示を仰ぐ",
    choices: [
      { label: "⏱ 発症後3.5時間以内（t-PA適応の可能性）", next: "r_tpa" },
      { label: "3.5時間超・または発症時刻不明", next: "r_stroke" },
    ],
  },
  adult_other_severe_check: {
    type: "checklist",
    mode: "categoryTally",
    title: "重症と判断すべき症状（急性腹症・呼吸器・婦人科）",
    instruction: "該当する項目をタップしてください（実施基準P11裏面「重症と判断すべき症状」より。いずれか1項目でも該当すればその区分の重症対応リストを表示）",
    categories: [
      {
        id: "abdomen",
        label: "腹痛（急性腹症）",
        dataKey: "abdomen",
        resultLabel: "急性腹症対応",
        items: [
          { id: "abd1", label: "腹壁緊張または圧痛" },
          { id: "abd2", label: "腹膜刺激症状" },
          { id: "abd3", label: "高度脱水" },
          { id: "abd4", label: "高度貧血" },
          { id: "abd5", label: "グル音消失" },
          { id: "abd6", label: "有響性金属性グル音" },
          { id: "abd7", label: "人工的妊娠中絶後" },
          { id: "abd8", label: "吐血、下血" },
          { id: "abd9", label: "腹部の異常膨張" },
          { id: "abd10", label: "頻回の嘔吐" },
        ],
      },
      {
        id: "respiratory",
        label: "呼吸困難（呼吸器疾患）",
        dataKey: "respiratory",
        resultLabel: "呼吸器疾患対応",
        items: [
          { id: "resp1", label: "チアノーゼ" },
          { id: "resp2", label: "起坐呼吸" },
          { id: "resp3", label: "胸痛" },
          { id: "resp4", label: "著明な浮腫" },
          { id: "resp5", label: "喀血（概ね100cc以上）" },
          { id: "resp6", label: "著明な喘鳴を伴う努力性呼吸" },
          { id: "resp7", label: "呼吸音の左右差" },
          { id: "resp8", label: "広範囲湿性ラ音・乾性ラ音" },
          { id: "resp9", label: "喘息重積発作" },
          { id: "resp10", label: "腎不全の人工透析治療中" },
          { id: "resp11", label: "心筋梗塞、弁膜症、心筋症" },
        ],
      },
      {
        id: "gynecology",
        label: "婦人科",
        dataKey: "gynecology",
        resultLabel: "婦人科疾患対応",
        items: [
          { id: "gyn1", label: "大量の不正出血" },
        ],
      },
    ],
    onTally: {
      "0": "adult_light_category_q",
      "1": "r_adult_category_pending",
      "2": "r_adult_category_pending",
      "3": "r_adult_category_pending",
    },
    tallyLabels: {
      "0": { label: "該当なし", color: "#0B7A3B" },
      "1": { label: "重症（該当あり）", color: "#B3261E" },
      "2": { label: "重症（該当あり）", color: "#B3261E" },
      "3": { label: "重症（該当あり）", color: "#B3261E" },
    },
  },

  // ---------- 小児（P18フロー） ----------
  peds_arrest_q: {
    q: "心肺停止が明らかですか？",
    sub: "心肺停止が明らかな場合は、重症度判定を待たず直近の対応可能な救急医療機関等へ搬送を開始する",
    choices: [
      { label: "はい（心肺停止）", next: "r_arrest" },
      { label: "いいえ", next: "peds_trauma_branch_q" },
    ],
  },
  peds_trauma_branch_q: {
    q: "外傷・熱傷・中毒によるものですか？",
    sub: "外傷・熱傷・中毒は年齢を問わず共通の搬送先選定フローを使用する（外傷観察カードは成人・乳幼児それぞれの基準に対応済み）",
    choices: [
      { label: "はい（外傷・熱傷・中毒）", next: "trauma_type_q" },
      { label: "いいえ（疾病）", next: "peds_observation" },
    ],
  },
  peds_observation: {
    type: "card",
    scoringMode: "categoryTally",
    cardImage: "peds",
    title: "疾病観察カード【小児】",
    instruction: "カード原本の画像上で、該当する項目を直接タップしてください。外観・呼吸・皮膚の3カテゴリーのうち、いずれかの項目が1つでも異常ならそのカテゴリーは「異常」。3つとも異常なら重症、1〜2つ異常なら重症の疑い",
    categoryLabels: { appearance: "外観", breath: "呼吸", skin: "皮膚" },
    rows: [
      { id: "p_tension", label: "筋緊張", category: "appearance", options: [
        { id: "p_t_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 27.44, x2: 40.3, y2: 33.37 } },
        { id: "p_t_abn", label: "動かない・診察に抵抗しない・坐位がとれない・四肢や頸部を支えていない", tier: "abnormal", box: { x1: 40.33, y1: 27.44, x2: 89.44, y2: 33.37 } },
      ]},
      { id: "p_reaction", label: "周囲への反応", category: "appearance", options: [
        { id: "p_r_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 33.37, x2: 40.3, y2: 39.3 } },
        { id: "p_r_abn", label: "周囲に気を配らない・物音に注意を払わない・診療器具に手を伸ばさない・保護者からの干渉に無関心", tier: "abnormal", box: { x1: 40.33, y1: 33.37, x2: 89.44, y2: 39.3 } },
      ]},
      { id: "p_stability", label: "精神的安定", category: "appearance", options: [
        { id: "p_s_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 39.3, x2: 40.3, y2: 45.23 } },
        { id: "p_s_abn", label: "保護者があやしても優しくしても落ち着かない", tier: "abnormal", box: { x1: 40.44, y1: 39.3, x2: 89.44, y2: 45.23 } },
      ]},
      { id: "p_gaze", label: "視線／注視", category: "appearance", options: [
        { id: "p_g_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 45.23, x2: 40.3, y2: 49.84 } },
        { id: "p_g_abn", label: "視線が合わない・ぼんやりしている", tier: "abnormal", box: { x1: 40.44, y1: 45.23, x2: 89.22, y2: 49.84 } },
      ]},
      { id: "p_talk", label: "会話／啼泣", category: "appearance", options: [
        { id: "p_ta_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 49.84, x2: 40.3, y2: 54.34 } },
        { id: "p_ta_abn", label: "自発的会話が不可能・泣く元気がない", tier: "abnormal", box: { x1: 40.44, y1: 49.84, x2: 89.44, y2: 54.34 } },
      ]},
      { id: "p_breath_state", label: "呼吸性状", category: "breath", options: [
        { id: "p_bs_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 56.31, x2: 40.3, y2: 63.45 } },
        { id: "p_bs_abn", label: "喘鳴・努力性呼吸・陥没呼吸・呻吟・鼻翼呼吸", tier: "abnormal", box: { x1: 40.33, y1: 56.31, x2: 89.22, y2: 63.45 } },
      ]},
      { id: "p_skin", label: "皮膚（循環）", category: "skin", options: [
        { id: "p_sk_normal", label: "正常", tier: "normal", box: { x1: 15.8, y1: 65.53, x2: 40.3, y2: 73.22 } },
        { id: "p_sk_abn", label: "暗紫色・末梢冷感・蒼白・まだら皮膚", tier: "abnormal", box: { x1: 40.44, y1: 65.53, x2: 89.22, y2: 73.22 } },
      ]},
      { id: "p_vital_breath", label: "呼吸（回/分）", category: null, options: [
        { id: "p_vb_normal", label: "測定値を記録", tier: "normal", box: { x1: 15.8, y1: 76.4, x2: 76.3, y2: 81.78 } },
        { id: "p_vb_none", label: "感ぜず", tier: "normal", box: { x1: 76.56, y1: 76.4, x2: 89.44, y2: 81.78 } },
      ]},
      { id: "p_vital_pulse", label: "脈拍（回/分）", category: null, options: [
        { id: "p_vp_normal", label: "測定値を記録", tier: "normal", box: { x1: 15.8, y1: 81.78, x2: 76.3, y2: 87.49 } },
        { id: "p_vp_none", label: "触れず", tier: "normal", box: { x1: 76.56, y1: 81.78, x2: 89.44, y2: 87.49 } },
      ]},
      { id: "p_bp", label: "血圧", category: null, options: [
        { id: "p_bp_val", label: "測定値を記録（　）／（　）mmHg", tier: "normal", box: { x1: 15.8, y1: 87.49, x2: 89.44, y2: 93.41 } },
      ]},
      { id: "p_spo2", label: "SpO2", category: null, options: [
        { id: "p_spo2_val", label: "測定値を記録（　）％", tier: "normal", box: { x1: 15.8, y1: 93.41, x2: 89.56, y2: 99.12 } },
      ]},
    ],
    onTally: { "3": "r_peds_severe", "2": "peds_suspect_category_q", "1": "peds_suspect_category_q", "0": "r_light_peds" },
    tallyLabels: {
      "3": { label: "重症", color: "#B3261E" },
      "2": { label: "重症の疑い", color: "#B26B00" },
      "1": { label: "重症の疑い", color: "#B26B00" },
      "0": { label: "該当なし（軽症の可能性）", color: "#0B7A3B" },
    },
  },

  // ---------- 妊産褥婦（P19フロー） ----------
  maternal_arrest_q: {
    q: "心肺停止が明らかですか？",
    sub: "心肺停止が明らかな場合は、重症度判定を待たず直近の対応可能な救急医療機関等へ搬送を開始する（自宅・車中分娩の場合は母子ともに搬送）",
    choices: [
      { label: "はい（心肺停止）", next: "r_arrest" },
      { label: "いいえ", next: "maternal_hometeisan_q" },
    ],
  },
  maternal_hometeisan_q: {
    q: "自宅（車中）分娩でしたか？",
    sub: "実施基準P19注1：自宅（車中）分娩については、母子ともに搬送する。該当する場合は疾病観察カード【自宅（車中）分娩における新生児】で新生児の状態も確認する",
    choices: [
      { label: "はい（自宅・車中分娩あり）", next: "maternal_newborn_q" },
      { label: "いいえ", next: "maternal_trauma_q" },
    ],
  },
  maternal_newborn_q: {
    q: "新生児の状態は？",
    sub: "疾病観察カード【自宅（車中）分娩における新生児】：①呼吸性状が弱い・感じず／②脈拍100回/分未満・触れず／③SpO2 90%未満／④ショック徴候（冷汗・皮膚蒼白・意識レベル低下）のいずれか一つでもあれば重症",
    choices: [
      { label: "該当（新生児重症）", next: "r_maternal_newborn" },
      { label: "非該当（新生児は安定）", next: "maternal_trauma_q" },
    ],
  },
  maternal_trauma_q: {
    q: "外傷・熱傷・中毒の合併がありますか？",
    sub: "交通外傷等で腹部打撲・胎動減少消失・切迫早産徴候のいずれかがある場合は妊産褥婦対応に準じる",
    choices: [
      { label: "なし（産科的緊急）", next: "maternal_severe_q" },
      { label: "あり（外傷等あり）", next: "maternal_trauma_ob_check_q" },
    ],
  },
  maternal_trauma_ob_check_q: {
    q: "交通外傷で、以下のいずれかを認めますか？",
    sub: "実施基準P20（注）：妊産婦の交通外傷の場合、以下のいずれかを認める場合には「医療機関リスト【妊産褥婦】」に準じて搬送する",
    choices: [
      { label: "認める（腹部打撲〈疑いを含む〉／胎動減少・消失／切迫早産徴候〈子宮収縮、性器出血〉のいずれかあり）", next: "r_maternal" },
      // 心肺停止は妊産褥婦フロー冒頭で確認済み、P20注記もここで確認済みなので、外傷の種類選択へ直接進む
      { label: "認めない／交通外傷ではない", next: "trauma_type_q" },
    ],
  },
  maternal_severe_q: {
    type: "card",
    cardImage: "maternal",
    title: "疾病観察カード【妊産褥婦】",
    instruction: "カード原本の画像上で、該当する項目を直接タップしてください（赤＝重症）。赤色の項目は1つでも該当すれば重症",
    rows: [
      { id: "m_consciousness", label: "意識", options: [
        { id: "m_c_normal", label: "30未満", tier: "normal", box: { x1: 16.5, y1: 13.38, x2: 52.5, y2: 16.55 } },
        { id: "m_c_severe", label: "30・100・200・300", tier: "red", box: { x1: 52.56, y1: 13.38, x2: 89.56, y2: 16.55 } },
      ]},
      { id: "m_resprate", label: "呼吸数", options: [
        { id: "m_rr_normal", label: "10〜30回/分", tier: "normal", box: { x1: 16.5, y1: 16.55, x2: 52.5, y2: 19.81 } },
        { id: "m_rr_severe", label: "10回/分未満・30回/分以上", tier: "red", box: { x1: 52.56, y1: 16.55, x2: 80.0, y2: 19.81 } },
        { id: "m_rr_none", label: "感ぜず", tier: "red", box: { x1: 80.44, y1: 16.55, x2: 89.56, y2: 19.81 } },
      ]},
      { id: "m_resp_lr", label: "呼吸（左右差）", options: [
        { id: "m_rlr_normal", label: "なし", tier: "normal", box: { x1: 16.5, y1: 19.81, x2: 52.5, y2: 22.98 } },
        { id: "m_rlr_yes", label: "あり", tier: "red", box: { x1: 52.56, y1: 19.81, x2: 89.56, y2: 22.98 } },
      ]},
      { id: "m_abnormal_breath", label: "異常呼吸", options: [
        { id: "m_ab_normal", label: "なし", tier: "normal", box: { x1: 16.5, y1: 22.98, x2: 52.5, y2: 26.16 } },
        { id: "m_ab_yes", label: "あり（呼吸）", tier: "red", box: { x1: 52.56, y1: 22.98, x2: 89.56, y2: 26.16 } },
      ]},
      { id: "m_pulserate", label: "脈拍数", options: [
        { id: "m_pr_normal", label: "50〜150回/分", tier: "normal", box: { x1: 16.5, y1: 26.16, x2: 52.5, y2: 29.93 } },
        { id: "m_pr_severe", label: "50回/分未満・150回/分以上", tier: "red", box: { x1: 52.56, y1: 26.16, x2: 80.0, y2: 29.93 } },
        { id: "m_pr_none", label: "触れず", tier: "red", box: { x1: 80.44, y1: 26.16, x2: 89.56, y2: 29.93 } },
      ]},
      { id: "m_bp", label: "収縮期血圧", options: [
        { id: "m_bp_normal", label: "90〜200mmHg", tier: "normal", box: { x1: 16.5, y1: 29.93, x2: 52.5, y2: 33.79 } },
        { id: "m_bp_severe", label: "90mmHg未満・200mmHg以上", tier: "red", box: { x1: 52.56, y1: 29.93, x2: 89.56, y2: 33.79 } },
      ]},
      { id: "m_si", label: "SI（脈拍／収縮期血圧）", options: [
        { id: "m_si_normal", label: "1未満", tier: "normal", box: { x1: 16.5, y1: 33.79, x2: 52.5, y2: 37.56 } },
        { id: "m_si_severe", label: "1以上", tier: "red", box: { x1: 52.56, y1: 33.79, x2: 89.56, y2: 37.56 } },
      ]},
      { id: "m_spo2", label: "SpO2", options: [
        { id: "m_spo2_normal", label: "90%以上", tier: "normal", box: { x1: 16.5, y1: 37.56, x2: 52.5, y2: 40.74 } },
        { id: "m_spo2_severe", label: "90%未満", tier: "red", box: { x1: 52.56, y1: 37.56, x2: 89.56, y2: 40.74 } },
      ]},
      { id: "m_shock", label: "ショック徴候", options: [
        { id: "m_shock_normal", label: "なし", tier: "normal", box: { x1: 16.5, y1: 40.74, x2: 52.5, y2: 44.6 } },
        { id: "m_shock_yes", label: "冷汗・皮膚蒼白・意識レベル低下・その他", tier: "red", box: { x1: 52.56, y1: 40.74, x2: 89.56, y2: 44.6 } },
      ]},
      { id: "m_hemorrhage", label: "大量の性器出血", options: [
        { id: "m_hem_normal", label: "なし", tier: "normal", box: { x1: 16.5, y1: 48.8, x2: 52.5, y2: 51.46 } },
        { id: "m_hem_yes", label: "あり（1,000ml以上）", tier: "red", box: { x1: 52.56, y1: 48.8, x2: 89.56, y2: 51.46 } },
      ]},
      { id: "m_abdominal_pain", label: "腹部激痛", options: [
        { id: "m_ap_normal", label: "なし", tier: "normal", box: { x1: 16.5, y1: 51.46, x2: 52.5, y2: 54.12 } },
        { id: "m_ap_yes", label: "あり", tier: "red", box: { x1: 52.56, y1: 51.46, x2: 89.56, y2: 54.12 } },
      ]},
      { id: "m_fetal_heart", label: "児心音", options: [
        { id: "m_fh_present", label: "あり", tier: "normal", box: { x1: 16.5, y1: 54.12, x2: 52.5, y2: 56.78 } },
        { id: "m_fh_100", label: "100以上", tier: "normal", box: { x1: 52.56, y1: 54.12, x2: 89.56, y2: 56.78 } },
      ]},
      { id: "m_kakaritsuke", label: "かかりつけ医の有無", options: [
        { id: "m_kk_yes", label: "あり", tier: "normal", box: { x1: 16.5, y1: 61.92, x2: 52.5, y2: 67.15 } },
        { id: "m_kk_no", label: "なし", tier: "normal", box: { x1: 52.56, y1: 61.92, x2: 89.56, y2: 67.15 } },
      ]},
    ],
    onSevere: "r_maternal",
    onClear: "maternal_kakaritsuke_q",
  },
  maternal_kakaritsuke_q: {
    q: "かかりつけ医はありますか？",
    sub: "未受診妊婦・母子手帳なし・県外からの旅行者の場合はリスト掲載医療機関へ搬送する",
    choices: [
      { label: "あり", next: "maternal_kakaritsuke_accept_q" },
      { label: "なし／未受診・母子手帳なし・県外旅行者", next: "r_maternal" },
    ],
  },
  maternal_kakaritsuke_accept_q: {
    q: "かかりつけ医療機関での受入れは可能ですか？",
    choices: [
      { label: "可能", next: "r_maternal_kakaritsuke" },
      { label: "不可能", next: "r_maternal" },
    ],
  },

  // ---------- 外傷・熱傷・中毒（P20フロー） ----------
  trauma_arrest_q: {
    q: "心肺停止が明らかですか？",
    sub: "心肺停止が明らかな場合は、重症度判定を待たず直近の対応可能な救急医療機関等へ搬送を開始する",
    choices: [
      { label: "はい（心肺停止）", next: "r_arrest" },
      { label: "いいえ", next: "trauma_maternal_q" },
    ],
  },
  // 実施基準P20【外傷・熱傷・中毒】フロー（注）を外傷ルートでも確認する。
  // 入口で「外傷・熱傷・中毒」を選んだ妊婦が、この注記を通らずに外傷リストへ進むのを防ぐ。
  trauma_maternal_q: {
    q: "妊産婦の交通外傷で、以下のいずれかを認めますか？",
    sub: "・腹部打撲（疑いを含む）\n・胎動減少・消失\n・切迫早産徴候（子宮収縮、性器出血）あり\n\n実施基準P20（注）：妊産婦の交通外傷の場合、上記のいずれかを認める場合には「医療機関リスト【妊産褥婦】」に準じて搬送する",
    choices: [
      { label: "認める（妊産婦の交通外傷で、上記のいずれかあり）", next: "r_maternal" },
      { label: "認めない／妊産婦の交通外傷ではない", next: "trauma_type_q" },
    ],
  },
  trauma_q: {
    type: "card",
    cardImage: "trauma",
    title: "外傷観察カード",
    instruction: "カード原本の画像上で、該当する項目を直接タップしてください（緑=通常、赤=赤枠）。赤枠は1つでも該当すれば重症",
    rows: [
      {
        id: "t_state",
        label: "状態",
        options: [
          {
            id: "t_state_normal",
            label: "歩行可能・不能（仰・側・腹・坐・その他）",
            tier: "normal",
            box: { x1: 32.89, y1: 15.25, x2: 83.11, y2: 18.11 },
          },
          { id: "t_state_collapse", label: "虚脱", tier: "red", box: { x1: 83.11, y1: 16.21, x2: 89.33, y2: 18.1 } },
        ],
      },
      {
        id: "t_face_color",
        label: "顔色",
        options: [
          { id: "t_face_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 18.11, x2: 42.33, y2: 20.43 } },
          { id: "t_face_yellow", label: "黄・紅潮", tier: "normal", box: { x1: 42.33, y1: 18.11, x2: 50, y2: 20.43 } },
          { id: "t_face_earthy", label: "土気色", tier: "normal", box: { x1: 50, y1: 18.11, x2: 69.78, y2: 20.43 } },
          { id: "t_face_pale", label: "蒼白・チアノーゼ", tier: "red", box: { x1: 69.78, y1: 18.61, x2: 86.78, y2: 20.41 } },
        ],
      },
      {
        id: "t_expression",
        label: "表情",
        options: [
          { id: "t_expr_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 20.43, x2: 42.33, y2: 22.92 } },
          {
            id: "t_expr_excited",
            label: "興奮・不安・苦悶",
            tier: "normal",
            box: { x1: 42.33, y1: 20.43, x2: 69.56, y2: 22.92 },
          },
          { id: "t_expr_blank", label: "無表情・うつろ", tier: "red", box: { x1: 69.56, y1: 21.01, x2: 86.78, y2: 22.9 } },
        ],
      },
      {
        id: "t_vomit",
        label: "嘔吐・失禁",
        options: [
          { id: "t_vi_none", label: "なし", tier: "normal", box: { x1: 32.89, y1: 22.92, x2: 42.33, y2: 25.02 } },
          {
            id: "t_vi_symptom",
            label: "嘔気・嘔吐・吐血・喀血",
            tier: "normal",
            box: { x1: 42.33, y1: 22.92, x2: 70.3, y2: 25.02 },
          },
          {
            id: "t_vi_incontinence",
            label: "失禁（大・小）",
            tier: "normal",
            box: { x1: 70.3, y1: 22.92, x2: 91, y2: 25.02 },
          },
        ],
      },
      {
        id: "t_skin",
        label: "皮膚体温等",
        options: [
          { id: "t_skin_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 25.02, x2: 42.33, y2: 27.55 } },
          {
            id: "t_skin_dry",
            label: "乾燥・発熱・湿潤・発汗・浮腫",
            tier: "normal",
            box: { x1: 42.33, y1: 25.02, x2: 77.44, y2: 27.55 },
          },
          { id: "t_cold_sweat", label: "冷汗", tier: "red", box: { x1: 77.56, y1: 25.73, x2: 82.44, y2: 27.53 } },
          { id: "t_cold_feeling", label: "冷感", tier: "normal", box: { x1: 82.44, y1: 25.02, x2: 89, y2: 27.55 } },
        ],
      },
      {
        id: "t_eyelid",
        label: "眼瞼結膜・爪床・四肢末梢",
        options: [
          { id: "t_eyelid_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 27.55, x2: 42.33, y2: 35.1 } },
          { id: "t_eyelid_pale", label: "蒼白・チアノーゼ", tier: "normal", box: { x1: 42.33, y1: 27.55, x2: 91, y2: 35.1 } },
        ],
      },
      {
        id: "t_consciousness",
        label: "意識",
        options: [
          { id: "t_clear", label: "清明", tier: "normal", box: { x1: 32.89, y1: 35.1, x2: 41, y2: 38.36 } },
          { id: "t_jcs1_10", label: "1・2・3・10", tier: "normal", box: { x1: 41, y1: 35.1, x2: 57, y2: 38.36 } },
          { id: "t_jcs20_30", label: "20・30", tier: "normal", box: { x1: 57, y1: 35.1, x2: 72.22, y2: 38.36 } },
          { id: "t_jcs100_300", label: "100・200・300", tier: "red", box: { x1: 72.22, y1: 36.45, x2: 90, y2: 38.42 } },
        ],
      },
      {
        id: "t_consciousness_state",
        label: "意識（性状）",
        options: [
          {
            id: "t_air",
            label: "A自発性喪失・I便尿失禁・R不穏状態・意識障害進行",
            tier: "normal",
            box: { x1: 32.89, y1: 38.36, x2: 91, y2: 40.26 },
          },
        ],
      },
      {
        id: "t_breath_state",
        label: "呼吸性状",
        options: [
          { id: "t_breath_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 40.26, x2: 42.33, y2: 41.19 } },
          {
            id: "t_shallow_deep",
            label: "浅・深・喘鳴",
            tier: "normal",
            box: { x1: 42.33, y1: 40.26, x2: 62.22, y2: 41.19 },
          },
          {
            id: "t_abnormal_breath",
            label: "異常（呼吸）",
            tier: "red",
            box: { x1: 62.22, y1: 41.17, x2: 88.11, y2: 43.05 },
          },
          {
            id: "t_insufficient_chest",
            label: "胸部挙上不十分",
            tier: "red",
            box: { x1: 49.78, y1: 43.57, x2: 66.22, y2: 45.45 },
          },
          { id: "t_no_breath", label: "感ぜず", tier: "red", box: { x1: 78.44, y1: 43.57, x2: 86.78, y2: 45.37 } },
        ],
      },
      {
        id: "t_resp_rate_adult",
        label: "呼吸数（成人）",
        options: [
          {
            id: "t_rr_adult_normal",
            label: "16〜19回/分（成人）",
            tier: "normal",
            box: { x1: 32.89, y1: 45.4, x2: 42.33, y2: 48.08 },
          },
          {
            id: "t_rr_adult_mid",
            label: "20〜29・10〜15回/分（成人）",
            tier: "normal",
            box: { x1: 42.33, y1: 45.4, x2: 74.67, y2: 48.08 },
          },
          {
            id: "t_rr_adult_extreme",
            label: "10未満または30以上（成人）",
            tier: "red",
            box: { x1: 74.67, y1: 46.05, x2: 90.78, y2: 48 },
          },
        ],
      },
      {
        id: "t_resp_rate_infant",
        label: "呼吸数（乳幼児）",
        options: [
          {
            id: "t_rr_infant_normal",
            label: "24〜30回/分（乳幼児）",
            tier: "normal",
            box: { x1: 32.89, y1: 48.08, x2: 42.33, y2: 50.54 },
          },
          {
            id: "t_rr_infant_mid",
            label: "31〜34・15〜23回/分（乳幼児）",
            tier: "normal",
            box: { x1: 42.33, y1: 48.08, x2: 74.67, y2: 50.54 },
          },
          {
            id: "t_rr_infant_extreme",
            label: "15未満または35以上（乳幼児）",
            tier: "red",
            box: { x1: 74.67, y1: 48.1, x2: 90.78, y2: 50.09 },
          },
        ],
      },
      {
        id: "t_breath_sound",
        label: "呼吸音",
        options: [
          { id: "t_bs_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 50.54, x2: 42.33, y2: 52.87 } },
          { id: "t_bs_lr_none", label: "左右差（なし）", tier: "normal", box: { x1: 42.33, y1: 50.54, x2: 57, y2: 52.87 } },
          { id: "t_bs_lr_yes", label: "左右差（あり）", tier: "red", box: { x1: 57, y1: 50.69, x2: 63.22, y2: 52.4 } },
          { id: "t_bs_rale", label: "乾性ラ音・湿性ラ音・狭窄音", tier: "normal", box: { x1: 63.22, y1: 50.54, x2: 91, y2: 52.87 } },
        ],
      },
      {
        id: "t_tension",
        label: "緊張度",
        options: [
          { id: "t_tension_normal", label: "正常", tier: "normal", box: { x1: 32.89, y1: 52.87, x2: 42.33, y2: 55.27 } },
          {
            id: "t_tension_strong_weak",
            label: "強・弱",
            tier: "normal",
            box: { x1: 42.33, y1: 52.87, x2: 56.67, y2: 55.27 },
          },
          {
            id: "t_tension_lr",
            label: "左右差（なし・あり）",
            tier: "normal",
            box: { x1: 56.67, y1: 52.87, x2: 81.56, y2: 55.27 },
          },
          { id: "t_tension_faint", label: "微弱", tier: "normal", box: { x1: 81.56, y1: 52.87, x2: 89, y2: 55.27 } },
        ],
      },
      {
        id: "t_rhythm_touch",
        label: "リズム・総頸動脈",
        options: [
          { id: "t_rhythm_normal", label: "整", tier: "normal", box: { x1: 32.89, y1: 55.27, x2: 42.33, y2: 57.29 } },
          {
            id: "t_rhythm_irregular",
            label: "不整",
            tier: "normal",
            box: { x1: 42.33, y1: 55.27, x2: 73.78, y2: 57.29 },
          },
          { id: "t_not_palpable", label: "総頸触れず", tier: "red", box: { x1: 73.78, y1: 55.49, x2: 87.22, y2: 57.29 } },
        ],
      },
      {
        id: "t_pulse_rate_adult",
        label: "脈拍数（成人）",
        options: [
          {
            id: "t_pr_adult_normal",
            label: "50〜100回/分（成人）",
            tier: "normal",
            box: { x1: 32.89, y1: 58.32, x2: 42.33, y2: 60.46 },
          },
          {
            id: "t_pr_adult_mid",
            label: "101〜119回/分（成人）",
            tier: "normal",
            box: { x1: 42.33, y1: 58.32, x2: 71.33, y2: 60.46 },
          },
          {
            id: "t_pr_adult_extreme",
            label: "50未満または120以上（成人）",
            tier: "red",
            box: { x1: 71.33, y1: 58.32, x2: 90.44, y2: 60.46 },
          },
        ],
      },
      {
        id: "t_pulse_rate_infant",
        label: "脈拍数（乳幼児）",
        options: [
          {
            id: "t_pr_infant_normal",
            label: "80〜120回/分（乳幼児）",
            tier: "normal",
            box: { x1: 32.89, y1: 62.01, x2: 42.33, y2: 63.98 },
          },
          {
            id: "t_pr_infant_mid",
            label: "121〜149回/分（乳幼児）",
            tier: "normal",
            box: { x1: 42.33, y1: 62.01, x2: 71.33, y2: 63.98 },
          },
          {
            id: "t_pr_infant_extreme",
            label: "80未満または150以上（乳幼児）",
            tier: "red",
            box: { x1: 71.33, y1: 62.01, x2: 90.44, y2: 63.98 },
          },
        ],
      },
      {
        id: "t_bp_lr",
        label: "血圧（測定値左右差）",
        options: [
          { id: "t_bp_lr_none", label: "左右差（なし）", tier: "normal", box: { x1: 32.89, y1: 63.94, x2: 60, y2: 66.06 } },
          { id: "t_bp_lr_yes", label: "左右差（あり）", tier: "normal", box: { x1: 60, y1: 63.94, x2: 91, y2: 66.06 } },
        ],
      },
      {
        id: "t_bp",
        label: "収縮期血圧",
        options: [
          {
            id: "t_bp_normal",
            label: "140〜90mmHg",
            tier: "normal",
            box: { x1: 32.89, y1: 66.06, x2: 42.33, y2: 67.54 },
          },
          { id: "t_bp_mid", label: "141〜199mmHg", tier: "normal", box: { x1: 42.33, y1: 66.06, x2: 61.11, y2: 71.66 } },
          {
            id: "t_bp_extreme",
            label: "90mmHg未満・200mmHg以上",
            tier: "red",
            box: { x1: 61.11, y1: 67.5, x2: 77.11, y2: 71.61 },
          },
          { id: "t_bp_unmeasurable", label: "測定不能", tier: "red", box: { x1: 79.11, y1: 68.1, x2: 89.89, y2: 71.1 } },
        ],
      },
      {
        id: "t_spo2",
        label: "SpO2",
        options: [
          { id: "t_spo2_normal", label: "93%〜", tier: "normal", box: { x1: 31, y1: 71.66, x2: 40, y2: 73.89 } },
          { id: "t_spo2_mid", label: "90〜92%", tier: "normal", box: { x1: 40, y1: 71.66, x2: 58.33, y2: 73.89 } },
          { id: "t_spo2_extreme", label: "90%未満", tier: "red", box: { x1: 63.22, y1: 72.13, x2: 87.78, y2: 73.93 } },
        ],
      },
      {
        id: "t_pupil_size",
        label: "瞳孔（大きさ）",
        options: [
          {
            id: "t_pupil_size_normal",
            label: "正常",
            tier: "normal",
            box: { x1: 32.89, y1: 74.36, x2: 42.33, y2: 76.76 },
          },
          {
            id: "t_pupil_size_abnormal",
            label: "縮小（両側）・不同（左＞・右＞）",
            tier: "normal",
            box: { x1: 42.33, y1: 74.36, x2: 77.78, y2: 76.76 },
          },
          { id: "t_pupil_size_dilated", label: "散大", tier: "normal", box: { x1: 77.78, y1: 74.36, x2: 91, y2: 76.76 } },
        ],
      },
      {
        id: "t_pupil_reflex",
        label: "瞳孔（反射）",
        options: [
          {
            id: "t_pupil_reflex_normal",
            label: "正常",
            tier: "normal",
            box: { x1: 32.89, y1: 76.76, x2: 42.33, y2: 79.16 },
          },
          {
            id: "t_pupil_reflex_dull",
            label: "にぶい",
            tier: "normal",
            box: { x1: 42.33, y1: 76.76, x2: 67.33, y2: 79.16 },
          },
          { id: "t_pupil_reflex_none", label: "なし", tier: "normal", box: { x1: 67.33, y1: 76.76, x2: 91, y2: 79.16 } },
        ],
      },
      {
        id: "t_pupil_deviation",
        label: "瞳孔（偏視）",
        options: [
          { id: "t_pupil_dev_none", label: "なし", tier: "normal", box: { x1: 32.89, y1: 79.16, x2: 42.33, y2: 81.39 } },
          {
            id: "t_pupil_dev_yes",
            label: "右・左・上・下・右斜め・左斜め・共同偏視",
            tier: "normal",
            box: { x1: 42.33, y1: 79.16, x2: 91, y2: 81.39 },
          },
        ],
      },
      {
        id: "t_pupil_diameter",
        label: "瞳孔径（mm）",
        options: [
          { id: "t_pd_1_2", label: "1〜2mm", tier: "normal", box: { x1: 33.22, y1: 81.39, x2: 42.22, y2: 86.62 } },
          { id: "t_pd_3_4", label: "3〜4mm", tier: "normal", box: { x1: 42.22, y1: 81.39, x2: 56.78, y2: 86.62 } },
          { id: "t_pd_5_8", label: "5〜8mm", tier: "normal", box: { x1: 56.78, y1: 81.39, x2: 84.89, y2: 86.62 } },
        ],
      },
    ],
    onSevere: "r_trauma_vital",
    onClear: "trauma_body_check",
  },
  trauma_local_q: {
    q: "主訴・局所状態による重症はどれに該当しますか？",
    sub: "実施基準P20：外見・バイタルサイン（全身観察を含む）で重症に該当しない場合、主訴・局所状態により重症と判断したものは該当するリストへ。該当しなければ直近の対応可能な医療機関",
    choices: [
      { label: "🦴 開放骨折", next: "r_trauma_fracture" },
      { label: "🦴 多発外傷", next: "r_trauma_multiple" },
      { label: "🧠 頭部外傷", next: "r_trauma_head" },
      { label: "🦴 脊椎（髄）損傷", next: "r_trauma_spine" },
      { label: "🩹 腹部外傷（泌尿器系を含む）", next: "r_trauma_abdomen" },
      { label: "🫁 胸部外傷（心外傷を含む）", next: "r_trauma_chest" },
      { label: "✂️ 切断指（再接着を要すもの）", next: "r_amputation_severe" },
      { label: "該当なし（重症以外）", next: "trauma_age_q" },
    ],
  },
  trauma_body_check: {
    type: "checklist",
    title: "外傷観察カード【裏面】：全身観察・受傷機転評価",
    instruction: "実施基準P20注記：外傷については観察カードの「全身観察」に該当するものを「外見・バイタルサインによる重症」に含む。赤枠の項目が1つでも該当すれば重症（バイタルサイン等重症対応）。【弱者・基礎疾患の評価（総合判断）】小児・高齢者・妊婦、重大な基礎疾患（心疾患・呼吸器疾患・糖尿病・透析・悪性腫瘍・肝硬変・出血性疾患・抗凝固剤服用・薬物中毒・病的肥満等）がある場合は、重症度を総合的に判断する",
    redItems: [
      { id: "tb1", label: "［全身観察］顔面・頸部の著しい損傷・膨張" },
      { id: "tb2", label: "［全身観察］頸部・胸部の皮下気腫" },
      { id: "tb3", label: "［全身観察］外頸静脈の著しい怒張" },
      { id: "tb4", label: "［全身観察］胸郭の動揺・変形、フレイルチェスト" },
      { id: "tb5", label: "［全身観察］胸部開放創、開放性気胸" },
      { id: "tb6", label: "［全身観察］緊張性気胸（頸部気管偏位など）" },
      { id: "tb7", label: "［全身観察］腹部の膨瘤、筋性防御" },
      { id: "tb8", label: "［全身観察］骨盤骨折（骨盤部の自発痛、圧痛、動揺、下肢長差）" },
      { id: "tb9", label: "［全身観察］一側の大腿骨開放骨折、両大腿閉鎖骨折" },
      { id: "tb10", label: "［全身観察］四肢2箇所以上の骨折" },
      { id: "tb11", label: "［全身観察］デグロービング損傷" },
      { id: "tb12", label: "［全身観察］四肢の轢断" },
      { id: "tb13", label: "［全身観察］開放性頭蓋骨折" },
      { id: "tb14", label: "［全身観察］頸部からソケイ部までの鋭的損傷" },
      { id: "tb15", label: "［全身観察］多指切断（手指2本以上、足趾3本以上）" },
      { id: "tb16", label: "［全身観察］四肢麻痺" },
      { id: "tb17", label: "［受傷機転］車外放出" },
      { id: "tb18", label: "［受傷機転］同乗者の死亡" },
      { id: "tb19", label: "［受傷機転］車に轢かれた" },
      { id: "tb20", label: "［受傷機転］車に跳ね飛ばされた" },
      { id: "tb21", label: "［受傷機転］車が高度に損傷している" },
      { id: "tb22", label: "［受傷機転］救出に20分以上要した" },
      { id: "tb23", label: "［受傷機転］車の横転" },
      { id: "tb24", label: "［受傷機転］バイクと傷病者の距離が大" },
      { id: "tb25", label: "［受傷機転］自動車と自転車、歩行者の衝突" },
      { id: "tb26", label: "［受傷機転］機械器具に巻き込まれた" },
      { id: "tb27", label: "［受傷機転］体幹部が挟まれた" },
      { id: "tb28", label: "［受傷機転］高所からの墜落" },
    ],
    blueItems: [],
    blueThreshold: 999,
    onSevere: "r_trauma_vital",
    onClear: "trauma_local_q",
  },
  burn_check: {
    type: "checklist",
    title: "熱傷観察カード【裏面】：主訴・局所状態／深度範囲／緊急度判断項目",
    instruction: "赤枠の項目が1つでも該当すれば重症熱傷対応",
    redItems: [
      { id: "bn0", label: "［麻痺］除脳硬直・除皮質硬直" },
      { id: "bn1", label: "Ⅱ度熱傷30%以上" },
      { id: "bn2", label: "Ⅲ度熱傷10%以上" },
      { id: "bn3", label: "化学損傷10%以上" },
      { id: "bn4", label: "電撃傷" },
      { id: "bn5", label: "気道熱傷" },
      { id: "bn6", label: "陰部・関節部の熱傷（Ⅱ度以上）" },
      { id: "bn7", label: "他の外傷の合併" },
      { id: "bn8", label: "Ⅱ度熱傷10%以上あるいはⅢ度熱傷5%以上（8歳未満70歳以上）" },
    ],
    blueItems: [],
    blueThreshold: 999,
    onSevere: "r_burn_severe",
    onClear: "trauma_age_q",
  },
  poison_check: {
    type: "checklist",
    title: "中毒観察カード【裏面】：主訴・局所状態／中毒原因物質（疑）",
    instruction: "赤枠の項目が1つでも該当すれば重症中毒対応",
    redItems: [
      { id: "pz0", label: "［麻痺］除脳硬直・除皮質硬直" },
      { id: "pz1", label: "意識レベルJCS20以上" },
      { id: "pz2", label: "おおむね50錠以上の服用" },
      { id: "pz3", label: "有害作用の特に強い医薬品の服用（アセトアミノフェン、三環系抗うつ薬等。ただし少量の服用を除く）" },
      { id: "pz4", label: "服用量が不明" },
      { id: "pz5", label: "農薬（パラコート、有機リン等の薬剤）" },
      { id: "pz6", label: "工業品（強酸、強アルカリ、石油製品、青酸化合物等）" },
      { id: "pz7", label: "覚せい剤及び麻薬" },
      { id: "pz8", label: "有毒ガス（一酸化炭素、液化石油ガス、硫化水素、窒素酸化物等）" },
      { id: "pz9", label: "毒性のある食物" },
      { id: "pz10", label: "何を飲んだか不明なもの" },
    ],
    blueItems: [],
    blueThreshold: 999,
    onSevere: "r_poison_severe",
    onClear: "trauma_age_q",
  },
  trauma_age_q: {
    q: "傷病者は15歳未満ですか？",
    sub: "「軽症：外傷・熱傷・中毒」の医療機関リストは15歳以上が対象。15歳未満は「軽症・小児」リストを使用する",
    choices: [
      { label: "15歳未満（小児）", next: "r_light_peds" },
      { label: "15歳以上", next: "r_light_trauma" },
    ],
  },

  // ---------- 精神疾患を疑われる傷病者（P21フロー） ----------
  psych_q1: {
    q: "以下の身体症状はありますか？（いずれか一つでも「有」なら緊急性ありとして該当フローを適用する）",
    sub: "小児・妊産褥婦・外傷/熱傷/中毒の場合／外見・バイタルサインによる重症／急性冠症候群の疑い／脳卒中の疑い／主訴・局所状態による重症（急性腹症・呼吸器・婦人科）／心肺停止",
    choices: [
      { label: "小児・妊産褥婦・外傷/熱傷/中毒の場合", next: "psych_route_case" },
      { label: "外見・バイタルサインによる重症", next: "r_vital_severe" },
      { label: "急性冠症候群の疑い", next: "r_ami" },
      { label: "脳卒中の疑い", next: "stroke_q" },
      { label: "主訴・局所状態による重症（急性腹症・呼吸器・婦人科）", next: "adult_other_severe_check" },
      { label: "心肺停止", next: "r_arrest" },
      { label: "いずれもなし", next: "psych_q2" },
    ],
  },
  psych_route_case: {
    q: "該当する区分は？",
    sub: "小児・妊産褥婦・外傷等それぞれの搬送先選定フローを適用する",
    choices: [
      { label: "小児", next: "peds_observation" },
      { label: "妊産褥婦", next: "maternal_severe_q" },
      { label: "外傷・熱傷・中毒", next: "trauma_type_q" },
    ],
  },
  psych_q2: {
    q: "精神症状（著しい興奮状態、極めて落ち着きがない、状況にそぐわない奇妙な行動、拒絶的でとりつくしまがない等）から、入院治療が必要な精神科疾患が疑われますか？",
    sub: "周囲の状況や家族等からの既往歴の聴取（最近の睡眠状態・食事量等）も踏まえて総合的に判断する",
    choices: [
      { label: "あり（精神科入院治療が必要と疑われる）", next: "r_psychiatric_beds" },
      { label: "なし", next: "adult_light_category_q" },
    ],
  },

  // ---------- 結果ノード（dataKeys配列。複数キーは公式フローで複数リストが同時提示される箇所） ----------
  r_arrest: { dataKeys: ["__arrest__"], label: "心肺停止" },

  r_vital_severe: { dataKeys: ["vital_severe"], label: "疾病：バイタルサイン等重症対応" },
  r_ami: { dataKeys: ["ami"], label: "急性心筋梗塞の疑い対応" },
  r_tpa: { dataKeys: ["tpa"], label: "t-PA対応（脳梗塞超急性期 発症3.5h以内）" },
  r_stroke: { dataKeys: ["stroke"], label: "脳卒中の疑い対応" },

  // [10/4版から復元]
  adult_light_category_q: {
    type: "categorySelect",
    title: "軽症：科目の選択",
    instruction: "重症の該当がない場合は、原則として直近の対応可能な医療機関へ搬送する。該当する科目をすべて選んでください（複数選択可）。選んだ科目のリスト（軽症・15歳以上）を表示します",
    resultLabelPrefix: "軽症：",
    items: [
      { id: "light_neuro", label: "中枢神経疾患（観察カードで「脳卒中の疑い」以外）" },
      { id: "light_digestive", label: "消化器疾患（観察カードで「重症の急性腹症」以外）" },
      { id: "light_respiratory", label: "呼吸器疾患（観察カードで「重症の呼吸器疾患」以外）" },
      { id: "light_trauma", label: "外傷・熱傷・中毒（観察カードで「重症」以外）" },
    ],
  },

  r_peds_severe: { dataKeys: ["peds_severe"], label: "小児：疾病：重症対応" },
  // 小児カード「疑い疾患分類」（原本P12）に対応。重症の疑いのとき、該当する分類のリスト（P18フロー）を表示する
  peds_suspect_category_q: {
    type: "categorySelect",
    title: "小児・重症の疑い：疑い疾患分類",
    instruction: "観察カード【小児】の「疑い疾患分類」で該当するものをすべて選んでください（複数選択可）。分類に迷う場合はすべて選ぶ",
    resultLabelPrefix: "小児・重症疑い：",
    items: [
      { id: "peds_neuro", label: "中枢神経疾患（痙攣・意識障害など）" },
      { id: "peds_respiratory", label: "呼吸器疾患（呼吸困難など）" },
      { id: "peds_circulatory", label: "循環器疾患（不整脈など）" },
      { id: "peds_digestive", label: "消化器疾患（腹痛・嘔吐など）" },
      { id: "peds_ingestion", label: "その他（誤飲など）" },
    ],
  },
  r_light_peds: { dataKeys: ["light_peds"], label: "軽症：小児（15歳未満）" },

  r_maternal: { dataKeys: ["maternal"], label: "妊産褥婦対応" },
  r_maternal_newborn: { dataKeys: ["maternal"], label: "妊産褥婦対応（自宅・車中分娩：新生児重症のため母子同時に周産期対応医療機関へ搬送）" },
  r_maternal_kakaritsuke: { dataKeys: ["__kakaritsuke__"], label: "かかりつけ医療機関" },

  r_trauma_vital: { dataKeys: ["trauma_vital"], label: "外傷・熱傷・中毒：バイタルサイン等重症対応" },
  r_burn_severe: { dataKeys: ["burn"], label: "重症熱傷対応" },
  r_poison_severe: { dataKeys: ["poison"], label: "重症中毒対応" },
  r_amputation_severe: { dataKeys: ["trauma_amputation"], label: "重症外傷：切断指対応（再接着を要すもの）" },

  r_light_trauma: { dataKeys: ["light_trauma"], label: "軽症：外傷・熱傷・中毒（重症以外）" },

  r_psychiatric_beds: { dataKeys: ["psychiatric_beds"], label: "精神病床のある救急医療機関" },

  // [10/4版から復元]
  trauma_type_q: {
    q: "外傷・熱傷・中毒のどれに該当しますか？",
    sub: "それぞれの観察カード（表面＝外見・バイタルサイン）で重症度を判断する。複合する場合は主たるものを選択",
    choices: [
      { label: "🦴 外傷", next: "trauma_q" },
      { label: "🔥 熱傷", next: "burn_front_check" },
      { label: "☠️ 中毒", next: "poison_front_check" },
    ],
  },

  // [10/4版から復元]
  r_trauma_fracture: { dataKeys: ["trauma_fracture"], label: "重症外傷：開放骨折対応" },

  // [10/4版から復元]
  r_trauma_multiple: { dataKeys: ["trauma_multiple"], label: "重症外傷：多発外傷対応" },

  // [10/4版から復元]
  r_trauma_head: { dataKeys: ["trauma_head"], label: "重症外傷：頭部外傷対応" },

  // [10/4版から復元]
  r_trauma_spine: { dataKeys: ["trauma_spine"], label: "重症外傷：脊椎（髄）損傷対応" },

  // [10/4版から復元]
  r_trauma_abdomen: { dataKeys: ["trauma_abdomen"], label: "重症外傷：腹部外傷対応（泌尿器系を含む）" },

  // [10/4版から復元]
  r_trauma_chest: { dataKeys: ["trauma_chest"], label: "重症外傷：胸部外傷対応（心外傷を含む）" },

  // [10/4版から復元]
  burn_front_check: {
    type: "checklist",
    title: "熱傷観察カード【表面】：外見・バイタルサイン",
    instruction: "赤枠は1つでも、青枠は2つ以上該当すれば重症（外傷・熱傷・中毒：バイタルサイン等重症対応）。赤色の項目は総合的に重症度を判断する",
    redItems: [
      { id: "bf_r1", label: "［状態］虚脱" },
      { id: "bf_r2", label: "［顔色］蒼白・チアノーゼ" },
      { id: "bf_r3", label: "［表情］無表情・うつろ" },
      { id: "bf_r4", label: "［皮膚体温等］冷汗" },
      { id: "bf_r5", label: "［呼吸性状］異常（呼吸）" },
      { id: "bf_r6", label: "［呼吸性状］胸部挙上不十分" },
      { id: "bf_r7", label: "［呼吸］感ぜず" },
      { id: "bf_r8", label: "［脈拍リズム］総頸触れず" },
    ],
    blueItems: [
      { id: "bf_b1", label: "［意識］JCS 100・200・300" },
      { id: "bf_b2", label: "［意識］意識障害進行" },
      { id: "bf_b3", label: "［呼吸数］10回/分未満・30回/分以上" },
      { id: "bf_b4", label: "［脈拍数］50回/分未満" },
      { id: "bf_b5", label: "［脈拍数］120回/分以上" },
      { id: "bf_b6", label: "［血圧］収縮期 90mmHg未満" },
      { id: "bf_b7", label: "［SpO2］90%未満" },
    ],
    blueThreshold: 2,
    onSevere: "r_trauma_vital",
    onClear: "burn_check",
  },

  // [10/4版から復元]
  poison_front_check: {
    type: "checklist",
    title: "中毒観察カード【表面】：外見・バイタルサイン",
    instruction: "赤枠は1つでも、青枠は2つ以上該当すれば重症（外傷・熱傷・中毒：バイタルサイン等重症対応）。赤色の項目は総合的に重症度を判断する",
    redItems: [
      { id: "pf_r1", label: "［状態］虚脱" },
      { id: "pf_r2", label: "［顔色］蒼白・チアノーゼ" },
      { id: "pf_r3", label: "［表情］無表情・うつろ" },
      { id: "pf_r4", label: "［皮膚体温等］冷汗" },
      { id: "pf_r5", label: "［呼吸性状］異常（呼吸）" },
      { id: "pf_r6", label: "［呼吸性状］胸部挙上不十分" },
      { id: "pf_r7", label: "［呼吸］感ぜず" },
      { id: "pf_r8", label: "［脈拍リズム］総頸触れず" },
    ],
    blueItems: [
      { id: "pf_b1", label: "［意識］JCS 100・200・300" },
      { id: "pf_b2", label: "［意識］意識障害進行" },
      { id: "pf_b3", label: "［呼吸数］10回/分未満・30回/分以上" },
      { id: "pf_b4", label: "［脈拍数］50回/分未満" },
      { id: "pf_b5", label: "［脈拍数］120回/分以上" },
      { id: "pf_b6", label: "［血圧］収縮期 90mmHg未満" },
      { id: "pf_b7", label: "［SpO2］90%未満" },
    ],
    blueThreshold: 2,
    onSevere: "r_trauma_vital",
    onClear: "poison_check",
  },
};
