import React, { useEffect, useState } from "react";

// 圏外のときだけ、保存済みの版で表示していることを知らせる帯
export default function OfflineNotice() {
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  if (online) return null;
  return (
    <div role="status" style={{
      background: "#FFF4D6", color: "#5C4300", borderBottom: "1px solid #E8B93A",
      padding: "8px 14px", fontSize: 12.5, fontWeight: 700, lineHeight: 1.5,
    }}>
      📴 圏外：端末に保存した版（{__APP_VERSION__}・{__BUILD_DATE__}作成）で表示中。通信が戻ると自動で最新版に更新されます。
    </div>
  );
}
