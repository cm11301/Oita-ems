import OfflineNotice from "./OfflineNotice.jsx";
import { timeSlot } from "./time.js";
import React, { useState, useMemo } from "react";
import { CARD_IMAGES } from "./assets/cardImages.js";
import { HOSPITAL_DATA } from "./data.js";
import { FLOW } from "./flow.js";

const LEVEL_ORDER = ["三次病院", "二次病院", "救急告示", "病院", "一般診療所", "小児救急支援病院（二次病院）"];
const LEVEL_COLOR = {
  "三次病院": "#B3261E",
  "二次病院": "#1155CC",
  "救急告示": "#0B7A3B",
  "病院": "#6B7280",
  "一般診療所": "#B8590A",
  "小児救急支援病院（二次病院）": "#B3261E",
};
const LEVEL_SHORT = {
  "三次病院": "三次",
  "二次病院": "二次",
  "救急告示": "救急告示",
  "病院": "病院",
  "一般診療所": "診療所",
  "小児救急支援病院（二次病院）": "三次相当",
};

const CATEGORY_LABELS = {
  vital_severe: "バイタルサイン等重症",
  ami: "急性心筋梗塞の疑い",
  tpa: "t-PA対応",
  stroke: "脳卒中の疑い",
  abdomen: "急性腹症（重症）",
  respiratory: "呼吸器疾患（重症）",
  gynecology: "婦人科疾患（重症）",
  peds_severe: "小児：重症",
  peds_neuro: "小児：中枢神経疾患",
  peds_respiratory: "小児：呼吸器疾患",
  peds_circulatory: "小児：循環器疾患",
  peds_digestive: "小児：消化器疾患",
  peds_ingestion: "小児：誤飲",
  light_peds: "軽症：小児",
  maternal: "妊産褥婦対応",
  trauma_vital: "外傷等バイタル重症",
  trauma_fracture: "開放骨折",
  trauma_multiple: "多発外傷",
  trauma_head: "頭部外傷",
  trauma_spine: "脊椎（髄）損傷",
  trauma_abdomen: "腹部外傷",
  trauma_chest: "胸部外傷",
  trauma_amputation: "切断指",
  burn: "重症熱傷",
  poison: "重症中毒",
  light_neuro: "軽症：中枢神経疾患",
  light_digestive: "軽症：消化器疾患",
  light_respiratory: "軽症：呼吸器疾患",
  light_trauma: "軽症：外傷・熱傷・中毒",
  psychiatric_beds: "精神病床のある救急医療機関",
};

function haversine([la1, lo1], [la2, lo2]) {
  const rad = (d) => (d * Math.PI) / 180;
  const dLa = rad(la2 - la1), dLo = rad(lo2 - lo1);
  const a = Math.sin(dLa / 2) ** 2 + Math.cos(rad(la1)) * Math.cos(rad(la2)) * Math.sin(dLo / 2) ** 2;
  return 12742 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function slotInfo(slot) {
  if (slot === "weekday_day") return { label: "通常診療時間内（平日9〜18時・土曜9〜12時）", color: "#0B7A3B", icon: "☀️" };
  if (slot === "weekday_night") return { label: "平日・診療時間外（夜間）", color: "#B8590A", icon: "🌙" };
  return { label: "休日・診療時間外", color: "#B3261E", icon: "📅" };
}

// 現在の対応可否を、区分に応じて判定する
function isAvailableNow(h, slot) {
  if (h.weekdayAvail !== undefined) {
    // 軽症カテゴリ：平日/休日で別データ。"partial"（△かかりつけ可等）も対応可として扱う
    const v = slot === "weekday_day" ? h.weekdayAvail : h.holidayAvail;
    return v === true || v === "partial";
  }
  // 重症系：afterHoursが true/partial なら時間外も対応、falseなら平日昼のみ
  if (slot === "weekday_day") return true;
  return h.afterHours === true || h.afterHours === "partial";
}
function isPartialAvail(h, slot) {
  if (h.weekdayAvail !== undefined) {
    const v = slot === "weekday_day" ? h.weekdayAvail : h.holidayAvail;
    return v === "partial";
  }
  if (slot === "weekday_day") return false;
  return h.afterHours === "partial";
}
function availNote(h, slot) {
  if (h.weekdayAvail !== undefined) {
    const note = slot === "weekday_day" ? h.weekdayNote : h.holidayNote;
    const v = slot === "weekday_day" ? h.weekdayAvail : h.holidayAvail;
    if (v === null) return "原本に記載なし・要確認";
    if (v === "partial") return note || "かかりつけ可";
    return note || "";
  }
  if (h.afterHours === "partial") {
    const extra = h.extraNote || h.note;
    return extra ? `初期対応のみ・${extra}` : "初期対応のみ";
  }
  return h.extraNote || h.note || "";
}

function Badge({ children, color = "#6B7280", outline }) {
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", gap: 4,
        fontSize: 12, fontWeight: 700, borderRadius: 6, padding: "3px 8px",
        color: outline ? color : "#fff",
        background: outline ? "#fff" : color,
        border: `1.5px solid ${color}`,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}

// 現在地にいちばん近い（位置確認済みの）病院の医療圏・市町村を返す。県外・全県の区分は除く
let _areaPoints = null;
export function nearestArea(pos) {
  if (!pos) return null;
  if (!_areaPoints) {
    const m = new Map();
    for (const list of Object.values(HOSPITAL_DATA)) for (const h of list) {
      if (h.lat == null || h.coordVerified === false || h.area === "全県" || h.area === "県外") continue;
      m.set(h.name, h);
    }
    _areaPoints = [...m.values()];
  }
  let best = null, bd = Infinity;
  for (const h of _areaPoints) {
    const d = haversine([pos.lat, pos.lng], [h.lat, h.lng]);
    if (d < bd) { bd = d; best = h; }
  }
  // 県境から遠く離れている（30km超）場合は推定しない
  return best && bd <= 30 ? { area: best.area, city: best.city } : null;
}

// 地図アプリ（Googleマップ）で経路案内を開くURL。位置を確認済みの病院は座標、それ以外は住所で検索
export function mapUrl(h) {
  const dest = h.lat != null && h.lng != null && h.coordVerified !== false
    ? `${h.lat},${h.lng}`
    : `${h.name} ${h.addr || h.city}`;
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}`;
}

function HospitalCard({ h, slot, rank, distance }) {
  const available = h._catTags ? h._anyAvail : isAvailableNow(h, slot);
  const partial = h._catTags ? false : isPartialAvail(h, slot);
  const note = h._catTags ? "" : availNote(h, slot);
  return (
    <div
      style={{
        background: "#fff",
        border: "1px solid #E4E4E0",
        borderLeft: `5px solid ${available ? (LEVEL_COLOR[h.type] || "#6B7280") : "#C9C9C4"}`,
        borderRadius: 10,
        padding: "14px 16px",
        display: "flex",
        gap: 12,
        opacity: available ? 1 : 0.72,
      }}
    >
      {distance != null && (
        <div
          style={{
            minWidth: 30, height: 30, borderRadius: "50%",
            background: rank < 3 ? "#FFF4D6" : "#F2F2EF",
            border: `1px solid ${rank < 3 ? "#E8B93A" : "#DADAD5"}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 12, fontWeight: 800, color: "#3A3A36", flexShrink: 0,
          }}
        >
          {rank + 1}
        </div>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 800, color: "#1A1A18", marginBottom: 6, lineHeight: 1.35 }}>
          {!available && <span style={{ marginRight: 6 }}>🔒</span>}
          {h.name}
          {h._catTags ? (
            h._catTags.map((t) => (
              <span key={t.label} title={t.avail ? "現在対応可" : `現在対応不可${t.note ? "：" + t.note : ""}`} style={{
                marginLeft: 6, fontSize: 11, fontWeight: 700,
                color: t.avail ? "#7A3FA0" : "#9A9A93",
                background: t.avail ? "#F1E8FA" : "#EDEDE9",
                borderRadius: 5, padding: "2px 7px", verticalAlign: "middle", display: "inline-block", marginTop: 3,
              }}>
                {t.label}{!t.avail && " 🔒"}
              </span>
            ))
          ) : h._catLabel && (
            <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 700, color: "#7A3FA0", background: "#F1E8FA", borderRadius: 5, padding: "2px 7px", verticalAlign: "middle" }}>
              {h._catLabel}
            </span>
          )}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginBottom: h.note || note || h.addr ? 6 : 0 }}>
          <Badge color={LEVEL_COLOR[h.type] || "#6B7280"}>{LEVEL_SHORT[h.type] || h.type}</Badge>
          <span style={{ fontSize: 12.5, color: "#57574F" }}>{h.city}</span>
          <span style={{ fontSize: 12, color: "#0B7A3B", background: "#E8F5EC", borderRadius: 5, padding: "2px 6px" }}>{h.area}医療圏</span>
          {h.admitCapable === true && <Badge color="#1155CC" outline>入院加療可</Badge>}
          {h.admitCapable === false && <Badge color="#6B7280" outline>初期対応のみ</Badge>}
          {available ? (
            partial ? (
              <Badge color="#B8590A">△ {note || "条件付き対応"}</Badge>
            ) : (
              <Badge color="#0B7A3B">✓ 現在対応可</Badge>
            )
          ) : (
            <span style={{ fontSize: 11.5, color: "#6B6B63", background: "#F2F2EF", border: "1px solid #DADAD5", borderRadius: 5, padding: "2px 7px" }}>
              🕐 {note || "時間外は要確認"}
            </span>
          )}
          {h.cath && (
            <Badge color="#7A3FA0" outline>
              心カテ{h.cath === "△" ? "：時間制限あり" : h.cath === "○" ? "：常時対応" : `：${h.cath}`}
            </Badge>
          )}
          {(h.ageMin || h.ageMax) && (
            <Badge color="#B8590A" outline>対応年齢 {h.ageMin || "0"}〜{h.ageMax || ""}歳</Badge>
          )}
          {distance != null && (
            <Badge color="#1155CC" outline>📍{distance < 10 ? distance.toFixed(1) : Math.round(distance)}km</Badge>
          )}
        </div>
        {h.ageBands && (
          <div style={{ fontSize: 11.5, color: "#57574F", marginBottom: 4 }}>
            対応：0〜1歳{h.ageBands["0-1"] ? "○" : "×"} / 2〜4歳{h.ageBands["2-4"] ? "○" : "×"} / 5〜11歳{h.ageBands["5-11"] ? "○" : "×"} / 12〜14歳{h.ageBands["12-14"] ? "○" : "×"}
          </div>
        )}
        {/* 原本の「備考」と「診療時間外の備考」を両方表示する（対応可否バッジに出した文言は重ねて出さない） */}
        {(() => {
          const badgeText = available && !partial ? "" : note;
          const lines = [];
          if (h.note && !String(badgeText).includes(h.note)) lines.push(h.note);
          if (h.extraNote && h.extraNote !== h.note && !String(badgeText).includes(h.extraNote)) lines.push(`時間外：${h.extraNote}`);
          return lines.map((t) => (
            <div key={t} style={{ fontSize: 12.5, color: "#B3261E", marginBottom: 3, lineHeight: 1.5 }}>※ {t}</div>
          ));
        })()}
        {h.addr && <div style={{ fontSize: 12, color: "#7A7A70", lineHeight: 1.5 }}>📍 {h.addr}</div>}
        {/* 受入れ照会の電話（代表番号）と、地図アプリでの経路案内 */}
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          {h.tel && (
            <a href={`tel:${h.tel.replace(/-/g, "")}`} onClick={(e) => e.stopPropagation()} aria-label={`${h.name}に電話`}
              style={{ flex: "3 1 0", minWidth: 0, whiteSpace: "nowrap", display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "9px 8px",
                borderRadius: 9, background: "#0B7A3B", color: "#fff", fontSize: 13.5, fontWeight: 800, textDecoration: "none" }}>
              📞 {h.tel}<span style={{ fontSize: 10.5, fontWeight: 600, opacity: 0.9 }}>代表</span>
            </a>
          )}
          <a href={mapUrl(h)} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} aria-label={`${h.name}を地図で開く`}
            style={{ flex: "2 1 0", minWidth: 0, whiteSpace: "nowrap", display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "9px 8px",
              borderRadius: 9, background: "#fff", border: "1.5px solid #1155CC", color: "#1155CC", fontSize: 13.5, fontWeight: 800, textDecoration: "none" }}>
            🗺 地図
          </a>
        </div>
      </div>
    </div>
  );
}

// 観察カード上部の「総合判断」欄に対応：赤色（ピンク）の項目などから総合的に重症と判断したときに使う
function SevereByJudgment({ onClick }) {
  return (
    <button onClick={onClick} style={{
      width: "100%", padding: 11, marginTop: 8, background: "#fff", border: "1.5px solid #B3261E", borderRadius: 12,
      color: "#B3261E", fontSize: 13.5, fontWeight: 800, cursor: "pointer", lineHeight: 1.4,
    }}>総合判断で重症とする<br /><span style={{ fontSize: 11, fontWeight: 600 }}>（赤色の項目などから総合的に重症と判断した場合）</span></button>
  );
}

function CardNode({ node, selections, onSelect, onConfirm }) {
  const tierColor = { normal: "#2E7D32", blue: "#1155CC", red: "#B3261E", abnormal: "#B3261E" };
  const tierBg = { normal: "#F7F7F4", blue: "#EAF1FB", red: "#FBEAEA", abnormal: "#FBEAEA" };
  const hasImageMap = node.cardImage && CARD_IMAGES[node.cardImage] &&
    node.rows.every((row) => row.options.every((o) => o.box));
  const isCategoryTally = node.scoringMode === "categoryTally";

  let redHit = false;
  let blueCount = 0;
  const categoryAbnormal = {};
  node.rows.forEach((row) => {
    const sel = selections[row.id];
    const opt = row.options.find((o) => o.id === sel);
    if (opt) {
      if (opt.tier === "red") redHit = true;
      if (opt.tier === "blue") blueCount += 1;
      if (isCategoryTally && row.category) {
        if (opt.tier === "abnormal") categoryAbnormal[row.category] = true;
        else if (!(row.category in categoryAbnormal)) categoryAbnormal[row.category] = false;
      }
    }
  });
  const tally = isCategoryTally ? Object.values(categoryAbnormal).filter(Boolean).length : 0;
  const isSevere = redHit || blueCount >= 2;
  const handleConfirm = () => {
    if (isCategoryTally) onConfirm(node.onTally[String(tally)]);
    else onConfirm(isSevere ? node.onSevere : node.onClear);
  };
  return (
    <div>
      {node.instruction && <div style={{ fontSize: 12.5, color: "#6B6B63", marginBottom: 14, lineHeight: 1.6 }}>{node.instruction}</div>}
      {hasImageMap ? (
        <div style={{ position: "relative", width: "100%", marginBottom: 14, borderRadius: 8, overflow: "hidden", border: "1px solid #DADAD5" }}>
          <img src={`data:image/jpeg;base64,${CARD_IMAGES[node.cardImage]}`} alt="観察カード原本"
            style={{ width: "100%", display: "block" }} />
          {node.rows.map((row) => row.options.map((opt) => {
            const isSelected = selections[row.id] === opt.id;
            const { x1, y1, x2, y2 } = opt.box;
            const color = tierColor[opt.tier];
            return (
              <button
                key={opt.id}
                onClick={() => onSelect(row.id, opt.id)}
                title={opt.label}
                style={{
                  position: "absolute",
                  left: `${x1}%`, top: `${y1}%`, width: `${x2 - x1}%`, height: `${y2 - y1}%`,
                  border: isSelected ? `3px solid ${color}` : "1px dashed rgba(0,0,0,0.15)",
                  background: isSelected ? `${color}55` : "rgba(255,255,255,0.01)",
                  borderRadius: 4, cursor: "pointer", padding: 0,
                }}
              />
            );
          }))}
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 14 }}>
          {node.rows.map((row) => (
            <div key={row.id} style={{ border: "1px solid #E4E4E0", borderRadius: 10, padding: 10, background: "#FAFAF8" }}>
              <div style={{ fontSize: 12, fontWeight: 800, color: "#57574F", marginBottom: 6 }}>{row.label}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {row.options.map((opt) => {
                  const isSelected = selections[row.id] === opt.id;
                  const color = tierColor[opt.tier];
                  return (
                    <button key={opt.id} onClick={() => onSelect(row.id, opt.id)} style={{
                      padding: "8px 10px", borderRadius: 8, cursor: "pointer", fontSize: 12.5, lineHeight: 1.4,
                      border: `1.5px solid ${isSelected ? color : "#DADAD5"}`,
                      background: isSelected ? color : (opt.tier === "normal" ? "#fff" : tierBg[opt.tier]),
                      color: isSelected ? "#fff" : (opt.tier === "normal" ? "#3A3A36" : color),
                      fontWeight: opt.tier === "normal" ? 500 : 700,
                    }}>
                      {opt.tier === "red" && "🔴 "}{opt.tier === "blue" && "🔵 "}{opt.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
      {hasImageMap && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
          {node.rows.map((row) => {
            const opt = row.options.find((o) => o.id === selections[row.id]);
            if (!opt) return null;
            const color = tierColor[opt.tier];
            return (
              <span key={row.id} style={{
                fontSize: 11.5, padding: "4px 9px", borderRadius: 8, fontWeight: 700,
                background: tierBg[opt.tier], color, border: `1px solid ${color}55`,
              }}>{row.label}：{opt.label}</span>
            );
          })}
        </div>
      )}
      {isCategoryTally ? (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "#F2F2EF", borderRadius: 10, padding: "10px 14px", marginBottom: 14 }}>
          <span style={{ fontSize: 12.5, color: "#57574F" }}>現在の判定（{tally}/{node.categoryLabels ? Object.keys(node.categoryLabels).length : 3}カテゴリー異常）</span>
          <span style={{ fontSize: 14, fontWeight: 800, color: tally === 0 ? "#0B7A3B" : "#B3261E" }}>
            {(node.tallyLabels && node.tallyLabels[String(tally)] && node.tallyLabels[String(tally)].label) || (tally === 0 ? "該当なし" : "該当あり")}
          </span>
        </div>
      ) : (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "#F2F2EF", borderRadius: 10, padding: "10px 14px", marginBottom: 14 }}>
          <span style={{ fontSize: 12.5, color: "#57574F" }}>現在の判定（赤枠{redHit ? "あり" : "なし"}／青枠{blueCount}個）</span>
          <span style={{ fontSize: 14, fontWeight: 800, color: isSevere ? "#B3261E" : "#0B7A3B" }}>{isSevere ? "重症" : "該当なし"}</span>
        </div>
      )}
      <button onClick={handleConfirm} style={{
        width: "100%", padding: 14, background: "#B3261E", border: "none", borderRadius: 12,
        color: "#fff", fontSize: 15, fontWeight: 800, cursor: "pointer",
      }}>この内容で判定する →</button>
      {isCategoryTally
        ? tally < 3 && <SevereByJudgment onClick={() => onConfirm(node.onTally["3"])} />
        : !isSevere && node.onSevere && <SevereByJudgment onClick={() => onConfirm(node.onSevere)} />}
    </div>
  );
}

function CategorySelectNode({ node, checked, onToggle, onConfirm }) {
  const selectedIds = node.items.filter((it) => checked.has(it.id)).map((it) => it.id);
  const selectedLabels = node.items.filter((it) => checked.has(it.id)).map((it) => it.label);
  return (
    <div>
      {node.instruction && <div style={{ fontSize: 12.5, color: "#6B6B63", marginBottom: 14, lineHeight: 1.6 }}>{node.instruction}</div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
        {node.items.map((it) => {
          const isChecked = checked.has(it.id);
          return (
            <button key={it.id} onClick={() => onToggle(it.id)} style={{
              textAlign: "left", padding: "12px 14px", borderRadius: 10, cursor: "pointer",
              border: `1.5px solid ${isChecked ? "#B3261E" : "#DADAD5"}`,
              background: isChecked ? "#B3261E" : "#fff", color: isChecked ? "#fff" : "#3A3A36",
              fontSize: 14, fontWeight: isChecked ? 700 : 500, display: "flex", gap: 10, alignItems: "center",
            }}>
              <span>{isChecked ? "☑" : "☐"}</span>
              <span>{it.label}</span>
            </button>
          );
        })}
      </div>
      <button
        disabled={selectedIds.length === 0}
        onClick={() => onConfirm(selectedIds, `${node.resultLabelPrefix || ""}${selectedLabels.join("・")}`)}
        style={{
          width: "100%", padding: 14, background: selectedIds.length === 0 ? "#DADAD5" : "#B3261E", border: "none", borderRadius: 12,
          color: "#fff", fontSize: 15, fontWeight: 800, cursor: selectedIds.length === 0 ? "not-allowed" : "pointer",
        }}>{selectedIds.length === 0 ? "少なくとも1つ選んでください" : "この内容で医療機関を表示 →"}</button>
    </div>
  );
}

function ChecklistNode({ node, checked, onToggle, onConfirm }) {
  if (node.mode === "categoryTally") {
    const tally = node.categories.filter((cat) => cat.items.some((it) => checked.has(it.id))).length;
    const defaultLabels = tally === node.categories.length
      ? { label: "重症", color: "#B3261E" }
      : tally >= 1
      ? { label: "重症の疑い", color: "#B26B00" }
      : { label: "軽症の可能性", color: "#0B7A3B" };
    const { label: resultLabel, color: resultColor } = (node.tallyLabels && node.tallyLabels[tally]) || defaultLabels;
    return (
      <div>
        {node.instruction && <div style={{ fontSize: 12.5, color: "#6B6B63", marginBottom: 14, lineHeight: 1.6 }}>{node.instruction}</div>}
        {node.categories.map((cat) => {
          const catAbnormal = cat.items.some((it) => checked.has(it.id));
          return (
            <div key={cat.id} style={{ marginBottom: 14, border: `1px solid ${catAbnormal ? "#EFC2C0" : "#E4E4E0"}`, borderRadius: 12, padding: 12, background: catAbnormal ? "#FBEAEA" : "#FAFAF8" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: "#2A2A26" }}>{cat.label}</span>
                <span style={{ fontSize: 11, fontWeight: 700, padding: "2px 10px", borderRadius: 10, background: catAbnormal ? "#B3261E" : "#DADAD5", color: catAbnormal ? "#fff" : "#57574F" }}>
                  {catAbnormal ? "異常あり" : "異常なし"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {cat.items.map((it) => {
                  const isChecked = checked.has(it.id);
                  return (
                    <button key={it.id} onClick={() => onToggle(it.id)} style={{
                      textAlign: "left", padding: "9px 11px", borderRadius: 9, cursor: "pointer",
                      border: `1px solid ${isChecked ? "#B3261E" : "#DADAD5"}`,
                      background: isChecked ? "#B3261E" : "#fff", color: isChecked ? "#fff" : "#3A3A36",
                      fontSize: 13, lineHeight: 1.5, display: "flex", gap: 8, alignItems: "flex-start",
                    }}>
                      <span style={{ flexShrink: 0 }}>{isChecked ? "☑" : "☐"}</span>
                      <span>{it.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "#F2F2EF", borderRadius: 10, padding: "10px 14px", marginBottom: 14 }}>
          <span style={{ fontSize: 12.5, color: "#57574F" }}>現在の判定（{tally}/{node.categories.length}カテゴリー異常）</span>
          <span style={{ fontSize: 14, fontWeight: 800, color: resultColor }}>{resultLabel}</span>
        </div>
        <button onClick={() => onConfirm(
          node.onTally[String(tally)],
          // 異常ありのカテゴリー（r_adult_category_pending で該当リストを並べて表示するのに使う）
          node.categories.filter((cat) => cat.items.some((it) => checked.has(it.id)))
        )} style={{
          width: "100%", padding: 14, background: "#B3261E", border: "none", borderRadius: 12,
          color: "#fff", fontSize: 15, fontWeight: 800, cursor: "pointer",
        }}>この内容で判定する →</button>
      </div>
    );
  }

  // redblue mode
  const redHit = node.redItems.some((it) => checked.has(it.id));
  const blueCount = (node.blueItems || []).filter((it) => checked.has(it.id)).length;
  const isSevere = redHit || blueCount >= (node.blueThreshold ?? 2);
  return (
    <div>
      {node.instruction && <div style={{ fontSize: 12.5, color: "#6B6B63", marginBottom: 14, lineHeight: 1.6 }}>{node.instruction}</div>}
      <div style={{ marginBottom: node.blueItems && node.blueItems.length > 0 ? 14 : 0 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#B3261E", marginBottom: 6 }}>
          🔴 赤枠（1つでも該当すれば重症）
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {node.redItems.map((it) => {
            const isChecked = checked.has(it.id);
            return (
              <button key={it.id} onClick={() => onToggle(it.id)} style={{
                textAlign: "left", padding: "9px 11px", borderRadius: 9, cursor: "pointer",
                border: `1px solid ${isChecked ? "#B3261E" : "#DADAD5"}`,
                background: isChecked ? "#B3261E" : "#fff", color: isChecked ? "#fff" : "#3A3A36",
                fontSize: 13, lineHeight: 1.5, display: "flex", gap: 8, alignItems: "flex-start",
              }}>
                <span style={{ flexShrink: 0 }}>{isChecked ? "☑" : "☐"}</span>
                <span>{it.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      {node.blueItems && node.blueItems.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 800, color: "#1155CC", marginBottom: 6 }}>
            🔵 青枠（{node.blueThreshold}つ以上該当すれば重症）
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {node.blueItems.map((it) => {
              const isChecked = checked.has(it.id);
              return (
                <button key={it.id} onClick={() => onToggle(it.id)} style={{
                  textAlign: "left", padding: "9px 11px", borderRadius: 9, cursor: "pointer",
                  border: `1px solid ${isChecked ? "#1155CC" : "#DADAD5"}`,
                  background: isChecked ? "#1155CC" : "#fff", color: isChecked ? "#fff" : "#3A3A36",
                  fontSize: 13, lineHeight: 1.5, display: "flex", gap: 8, alignItems: "flex-start",
                }}>
                  <span style={{ flexShrink: 0 }}>{isChecked ? "☑" : "☐"}</span>
                  <span>{it.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "#F2F2EF", borderRadius: 10, padding: "10px 14px", marginBottom: 14 }}>
        <span style={{ fontSize: 12.5, color: "#57574F" }}>現在の判定</span>
        <span style={{ fontSize: 14, fontWeight: 800, color: isSevere ? "#B3261E" : "#0B7A3B" }}>{isSevere ? "重症" : "該当なし"}</span>
      </div>
      <button onClick={() => onConfirm(isSevere ? node.onSevere : node.onClear)} style={{
        width: "100%", padding: 14, background: "#B3261E", border: "none", borderRadius: 12,
        color: "#fff", fontSize: 15, fontWeight: 800, cursor: "pointer",
      }}>この内容で判定する →</button>
      {!isSevere && node.onSevere && <SevereByJudgment onClick={() => onConfirm(node.onSevere)} />}
    </div>
  );
}

export default function App() {
  const [nodeId, setNodeId] = useState("start");
  const [history, setHistory] = useState([]);
  const [resultKeys, setResultKeys] = useState([]);
  const [resultLabel, setResultLabel] = useState("");
  // 医療圏・市町村の初期表示：現在地が取れれば最寄りの医療圏・市町村、取れなければ大分医療圏・大分市
  const [areaFilter, setAreaFilter] = useState("大分");
  const [cityFilter, setCityFilter] = useState("大分市");
  const [areaTouched, setAreaTouched] = useState(false); // 手で選び直したら、そのケースの間は自動で変えない
  const [levelFilter, setLevelFilter] = useState(new Set(LEVEL_ORDER));
  const [onlyAvailable, setOnlyAvailable] = useState(true); // デフォルトで対応可能な医療機関のみ表示
  const [now] = useState(() => new Date());
  const [myPos, setMyPos] = useState(null); // {lat,lng}
  const [geoStatus, setGeoStatus] = useState("idle"); // idle|loading|ok|denied|unavailable
  const [sortByDistance, setSortByDistance] = useState(true);
  const [checklistChecked, setChecklistChecked] = useState(new Set());
  const [cardSelections, setCardSelections] = useState({});

  React.useEffect(() => { setChecklistChecked(new Set()); setCardSelections({}); }, [nodeId]);

  const toggleChecklistItem = (id) => {
    setChecklistChecked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const selectCardOption = (rowId, optionId) => {
    setCardSelections((prev) => {
      const next = { ...prev };
      if (next[rowId] === optionId) delete next[rowId]; else next[rowId] = optionId;
      return next;
    });
  };

  const requestLocation = () => {
    if (!navigator.geolocation) { setGeoStatus("unavailable"); return; }
    setGeoStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setMyPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGeoStatus("ok");
      },
      (err) => { setGeoStatus(err.code === 1 ? "denied" : "unavailable"); },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  React.useEffect(() => { requestLocation(); }, []);

  // 時間帯：通常は現在時刻から自動判定。臨時休診などに備え手動で切り替えられる（null＝自動）
  const [slotOverride, setSlotOverride] = useState(null);
  const autoSlot = timeSlot(now);
  const slot = slotOverride || autoSlot;
  const sInfo = slotInfo(slot);
  const node = FLOW[nodeId];

  const [pendingCategory, setPendingCategory] = useState(null);
  const TRAUMA_CATEGORY_LABELS = {
    trauma_fracture: "開放骨折対応", trauma_multiple: "多発外傷対応", trauma_head: "頭部外傷対応",
    trauma_spine: "脊椎（髄）損傷対応", trauma_abdomen: "腹部外傷対応", trauma_chest: "胸部外傷対応",
  };
  const goTo = (choice) => {
    setHistory((h) => [...h, nodeId]);
    if (choice.setCategory) setPendingCategory(choice.setCategory);
    const next = FLOW[choice.next];
    if (next.dataKeys !== undefined) {
      setResultKeys(next.dataKeys);
      setResultLabel(next.label);
      setNodeId("result");
    } else {
      setNodeId(choice.next);
    }
  };
  const goToChecklistResult = (targetId, abnormalCategories) => {
    setHistory((h) => [...h, nodeId]);
    if (targetId === "r_trauma_category_pending" && pendingCategory) {
      setResultKeys([pendingCategory]);
      setResultLabel(`重症外傷対応：${TRAUMA_CATEGORY_LABELS[pendingCategory] || pendingCategory}`);
      setNodeId("result");
      return;
    }
    // 成人一般：異常ありカテゴリーごとの医療機関リストをまとめて表示
    if (targetId === "r_adult_category_pending" && abnormalCategories && abnormalCategories.length > 0) {
      setResultKeys(abnormalCategories.map((cat) => cat.dataKey));
      setResultLabel(abnormalCategories.map((cat) => cat.resultLabel).join("・"));
      setNodeId("result");
      return;
    }
    const next = FLOW[targetId];
    if (next.dataKeys !== undefined) {
      setResultKeys(next.dataKeys);
      setResultLabel(next.label);
      setNodeId("result");
    } else {
      setNodeId(targetId);
    }
  };
  const goToCategorySelectResult = (selectedIds, labelText) => {
    setHistory((h) => [...h, nodeId]);
    setResultKeys(selectedIds);
    setResultLabel(labelText);
    setNodeId("result");
  };
  const goBack = () => {
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setNodeId(prev || "start");
    if (history.length <= 1) setResultKeys([]);
  };
  const reset = () => {
    setNodeId("start"); setHistory([]); setResultKeys([]); setResultLabel("");
    const home = nearestArea(myPos);
    setAreaFilter(home ? home.area : "大分"); setCityFilter(home ? home.city : "大分市"); setAreaTouched(false);
    setLevelFilter(new Set(LEVEL_ORDER)); setOnlyAvailable(true);
    setPendingCategory(null);
  };

  const isSpecialResult = resultKeys.length === 1 && (resultKeys[0] === "__arrest__" || resultKeys[0] === "__kakaritsuke__");
  const isMultiResult = resultKeys.length > 1;
  const rawList = useMemo(() => {
    if (resultKeys.length === 0 || isSpecialResult) return [];
    return resultKeys.flatMap((k) =>
      (HOSPITAL_DATA[k] || []).map((h) => ({ ...h, _cat: k, _catLabel: CATEGORY_LABELS[k] || k }))
    );
  }, [resultKeys, isSpecialResult]);

  const areas = useMemo(() => {
    const s = new Set(rawList.map((h) => h.area));
    return ["全て", ...Array.from(s)];
  }, [rawList]);

  // 現在地が取れたら、手で選び直していない限り最寄りの医療圏・市町村にする
  const homeArea = useMemo(() => nearestArea(myPos), [myPos]);
  React.useEffect(() => {
    if (!homeArea || areaTouched) return;
    setAreaFilter(homeArea.area);
    setCityFilter(homeArea.city);
  }, [homeArea]); // eslint-disable-line react-hooks/exhaustive-deps

  // 結果カテゴリによっては選んだ医療圏の該当施設が無い場合があるため、その時は「全て」にフォールバックする
  React.useEffect(() => {
    if (rawList.length === 0) return;
    if (areaFilter !== "全て" && !areas.includes(areaFilter)) {
      setAreaFilter("全て");
    }
  }, [areas, areaFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const cities = useMemo(() => {
    if (areaFilter === "全て") return ["全て"];
    const s = new Set(rawList.filter((h) => h.area === areaFilter).map((h) => h.city));
    return ["全て", ...Array.from(s)];
  }, [rawList, areaFilter]);

  // 結果カテゴリによっては大分市の該当施設が無い場合があるため、その時は「全て」にフォールバックする
  React.useEffect(() => {
    if (rawList.length === 0) return;
    if (cityFilter !== "全て" && !cities.includes(cityFilter)) {
      setCityFilter("全て");
    }
  }, [cities, cityFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const areaFilteredList = useMemo(() => {
    let list = rawList;
    if (areaFilter !== "全て") {
      list = list.filter((h) => h.area === areaFilter);
      if (cityFilter !== "全て") list = list.filter((h) => h.city === cityFilter);
    }
    return list;
  }, [rawList, areaFilter, cityFilter]);

  const filtered = useMemo(() => {
    let list = areaFilteredList.map((h) => ({
      ...h,
      // 一般診療所と座標未確定（coordVerified:false）の施設は距離を出さない
      dist: myPos && h.lat != null && h.type !== "一般診療所" && h.coordVerified !== false
        ? haversine([myPos.lat, myPos.lng], [h.lat, h.lng]) : null,
    }));
    list = list.filter((h) => levelFilter.has(h.type));
    if (sortByDistance && myPos) {
      list.sort((a, b) => {
        if (a.dist != null && b.dist != null) return a.dist - b.dist;
        if (a.dist != null) return -1;
        if (b.dist != null) return 1;
        return 0;
      });
    }
    if (onlyAvailable) list = list.filter((h) => isAvailableNow(h, slot));
    return list;
  }, [areaFilteredList, levelFilter, onlyAvailable, slot, myPos, sortByDistance]);

  const levelCounts = useMemo(() => {
    const c = {};
    if (isMultiResult) {
      const seen = new Set();
      areaFilteredList.forEach((h) => {
        if (seen.has(h.name)) return;
        seen.add(h.name);
        c[h.type] = (c[h.type] || 0) + 1;
      });
    } else {
      areaFilteredList.forEach((h) => { c[h.type] = (c[h.type] || 0) + 1; });
    }
    return LEVEL_ORDER.filter((l) => c[l]).map((l) => [l, c[l]]);
  }, [areaFilteredList, isMultiResult]);

  const uniqueRawCount = useMemo(() => {
    if (!isMultiResult) return rawList.length;
    return new Set(rawList.map((h) => h.name)).size;
  }, [rawList, isMultiResult]);

  const displayList = useMemo(() => {
    if (!isMultiResult) return filtered;
    const map = new Map();
    for (const h of filtered) {
      const key = h.name;
      const tag = { label: h._catLabel, avail: isAvailableNow(h, slot), note: availNote(h, slot), raw: h };
      if (!map.has(key)) {
        map.set(key, { ...h, _catTags: [tag] });
      } else {
        const existing = map.get(key);
        if (!existing._catTags.some((t) => t.label === tag.label)) existing._catTags.push(tag);
      }
    }
    // カード全体としては、いずれか1区分でも現在対応可なら対応可扱いにする
    return Array.from(map.values()).map((h) => ({
      ...h,
      _anyAvail: h._catTags.some((t) => t.avail),
    }));
  }, [filtered, isMultiResult, slot]);

  const availCount = displayList.filter((h) => (h._catTags ? h._anyAvail : isAvailableNow(h, slot))).length;

  return (
    <div style={{ minHeight: "100vh", background: "#F7F7F4", color: "#1A1A18", fontFamily: "'BIZ UDPGothic','Hiragino Sans','Noto Sans JP',sans-serif" }}>
      <div style={{
        background: "#B3261E", padding: "14px 18px", display: "flex", alignItems: "center", gap: 12,
        position: "sticky", top: 0, zIndex: 100, boxShadow: "0 2px 10px rgba(0,0,0,.15)",
      }}>
        <span style={{ fontSize: 24 }}>🚑</span>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#FBD5D2", letterSpacing: 2 }}>大分県</div>
          <div style={{ fontSize: 16, fontWeight: 900, color: "#fff", letterSpacing: 0.5 }}>救急搬送先選定支援</div>
        </div>
        {nodeId !== "start" && (
          <button onClick={reset} style={{
            marginLeft: "auto", background: "rgba(255,255,255,.18)", border: "1px solid rgba(255,255,255,.3)",
            borderRadius: 20, padding: "7px 14px", color: "#fff", fontSize: 12.5, fontWeight: 700, cursor: "pointer",
          }}>🔄 最初から</button>
        )}
      </div>
      <OfflineNotice />

      <div style={{ padding: "14px 14px 40px", maxWidth: 700, margin: "0 auto" }}>
        {nodeId === "result" ? (
          <div style={{ marginTop: 6 }}>
            <div style={{ background: "#fff", border: "1px solid #E4E4E0", borderLeft: "5px solid #0B7A3B", borderRadius: 10, padding: "14px 18px", marginBottom: 10 }}>
              <div style={{ fontSize: 11, color: "#0B7A3B", fontWeight: 700, marginBottom: 4 }}>✓ 該当医療機関リスト</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1A1A18", lineHeight: 1.5 }}>{resultLabel}</div>
              {resultKeys.length > 0 && !isSpecialResult && (
                <div style={{ fontSize: 12.5, color: "#57574F", marginTop: 4 }}>
                  {isMultiResult ? "実質" : "全"}{uniqueRawCount}施設 / 表示{displayList.length}施設
                  {slot !== "weekday_day" && (
                    <> （現在対応可：<b style={{ color: "#0B7A3B" }}>{availCount}</b>施設 / 時間外不可：<b style={{ color: "#B3261E" }}>{displayList.length - availCount}</b>施設）</>
                  )}
                </div>
              )}
            </div>

            {resultKeys[0] === "__arrest__" ? (
              <div style={{ background: "#fff", border: "1px solid #E4E4E0", borderLeft: "5px solid #B3261E", borderRadius: 10, padding: "16px 18px", fontSize: 14, lineHeight: 1.9, color: "#3A3A36" }}>
                🚨 <b>心肺停止：直近の対応可能な救急医療機関等へ</b><br />
                心肺停止が明らかな場合は、重症度・区分の判定を待たず、速やかに直近の対応可能な救急医療機関等への搬送を開始してください。医療機関リストによる選定より搬送開始を優先します。
              </div>
            ) : resultKeys[0] === "__kakaritsuke__" ? (
              <div style={{ background: "#fff", border: "1px solid #E4E4E0", borderLeft: "5px solid #0B7A3B", borderRadius: 10, padding: "16px 18px", fontSize: 14, lineHeight: 1.9, color: "#3A3A36" }}>
                🏥 <b>かかりつけ医療機関へ搬送</b><br />
                かかりつけ医療機関での受入れが可能と確認できたため、当該医療機関へ搬送してください。かかりつけ医の判断により、状況に応じて高次の医療機関へ転送する場合があります。
              </div>
            ) : (
              <>
                {isMultiResult && (
                  <div style={{ background: "#EAF1FB", border: "1px solid #C7D9F0", borderRadius: 10, padding: "9px 14px", marginBottom: 10, fontSize: 12, color: "#1A3A6B", lineHeight: 1.6 }}>
                    ℹ️ 公式フローでは以下の複数区分のリストがまとめて提示されます。各カードのタグで区分を確認してください：{resultKeys.map((k) => CATEGORY_LABELS[k] || k).join(" / ")}
                  </div>
                )}
                <div style={{

                  borderRadius: 10, padding: "10px 14px", marginBottom: 10,
                  background: `${sInfo.color}14`, border: `1px solid ${sInfo.color}55`,
                  display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap",
                }}>
                  <span style={{ fontSize: 18 }}>{sInfo.icon}</span>
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 700, color: sInfo.color }}>{sInfo.label}</div>
                    <div style={{ fontSize: 11.5, color: "#6B6B63" }}>
                      {now.toLocaleDateString("ja-JP", { weekday: "long", month: "long", day: "numeric" })}{" "}
                      {now.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}
                      {slotOverride ? "（手動で切替中）" : "（自動判定）"}
                    </div>
                  </div>
                  <select aria-label="時間帯の切替" value={slotOverride || "auto"}
                    onChange={(e) => setSlotOverride(e.target.value === "auto" ? null : e.target.value)}
                    style={{ fontSize: 12, padding: "5px 6px", borderRadius: 8, border: "1px solid #DADAD5", background: "#fff", color: "#3A3A36" }}>
                    <option value="auto">時間帯：自動</option>
                    <option value="weekday_day">通常診療時間内</option>
                    <option value="weekday_night">平日・夜間</option>
                    <option value="holiday">休日・年末年始</option>
                  </select>
                  {slot !== "weekday_day" && (
                    <button onClick={() => setOnlyAvailable((v) => !v)} style={{
                      marginLeft: "auto", padding: "6px 12px",
                      background: onlyAvailable ? "#B3261E" : "#fff",
                      border: `1px solid ${onlyAvailable ? "#B3261E" : "#DADAD5"}`,
                      borderRadius: 8, color: onlyAvailable ? "#fff" : "#3A3A36", fontSize: 12, cursor: "pointer", fontWeight: 700,
                    }}>{onlyAvailable ? "✓ 対応可のみ表示中" : "対応可のみ表示"}</button>
                  )}
                </div>

                <div style={{
                  borderRadius: 10, padding: "10px 14px", marginBottom: 10,
                  background: geoStatus === "ok" ? "#E8F5EC" : "#F2F2EF",
                  border: `1px solid ${geoStatus === "ok" ? "#BEE3C8" : "#DADAD5"}`,
                  display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap",
                }}>
                  {geoStatus === "loading" && <span style={{ fontSize: 12.5, color: "#57574F" }}>📍 現在地を取得中…</span>}
                  {geoStatus === "ok" && (
                    <>
                      <span style={{ fontSize: 12.5, color: "#0B7A3B", fontWeight: 700 }}>📍 現在地から距離順に表示中</span>
                      <button onClick={() => setSortByDistance((v) => !v)} style={{
                        marginLeft: "auto", padding: "5px 11px",
                        background: sortByDistance ? "#0B7A3B" : "#fff",
                        border: `1px solid ${sortByDistance ? "#0B7A3B" : "#DADAD5"}`,
                        borderRadius: 8, color: sortByDistance ? "#fff" : "#57574F", fontSize: 11.5, cursor: "pointer", fontWeight: 700,
                      }}>{sortByDistance ? "✓ 距離順" : "距離順にする"}</button>
                    </>
                  )}
                  {geoStatus === "denied" && (
                    <>
                      <span style={{ fontSize: 12, color: "#57574F" }}>📍 位置情報の利用が許可されていません（端末の設定から許可すると距離順表示できます）</span>
                      <button onClick={requestLocation} style={{ marginLeft: "auto", padding: "5px 11px", background: "#fff", border: "1px solid #DADAD5", borderRadius: 8, fontSize: 11.5, cursor: "pointer", fontWeight: 700, color: "#57574F" }}>再試行</button>
                    </>
                  )}
                  {geoStatus === "unavailable" && (
                    <span style={{ fontSize: 12, color: "#57574F" }}>📍 この端末では位置情報を取得できませんでした（医療圏・市町村で絞り込んでください）</span>
                  )}
                </div>

                <div style={{ background: "#FBEAEA", border: "1px solid #EFC2C0", borderRadius: 10, padding: "9px 14px", marginBottom: 14, fontSize: 12, color: "#8C2A26", lineHeight: 1.6 }}>
                  ⚠️ いずれの医療機関においても状況により対応不可となる場合があります。搬送の際は必ず受入れ可否を照会してください。
                </div>

                <div style={{ background: "#fff", border: "1px solid #E4E4E0", borderRadius: 10, padding: "12px 14px", marginBottom: 12 }}>
                  <div style={{ fontSize: 11.5, color: "#6B6B63", fontWeight: 700, marginBottom: 8 }}>
                    ① 医療圏を選択
                    {homeArea && !areaTouched && areaFilter === homeArea.area && (
                      <span style={{ marginLeft: 6, fontWeight: 600, color: "#0B7A3B" }}>（現在地から自動選択）</span>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: areaFilter === "全て" ? 0 : 12 }}>
                    {areas.map((a) => (
                      <button key={a} onClick={() => { setAreaFilter(a); setCityFilter("全て"); setAreaTouched(true); }} style={{
                        padding: "5px 11px", borderRadius: 20, fontSize: 12, fontWeight: 700, cursor: "pointer",
                        background: areaFilter === a ? "#1155CC" : "#F2F2EF",
                        border: `1px solid ${areaFilter === a ? "#1155CC" : "#DADAD5"}`,
                        color: areaFilter === a ? "#fff" : "#57574F",
                      }}>{a}</button>
                    ))}
                  </div>
                  {areaFilter !== "全て" && cities.length > 1 && (
                    <>
                      <div style={{ fontSize: 11.5, color: "#6B6B63", fontWeight: 700, marginBottom: 8 }}>
                        ② 市町村を選択
                      </div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {cities.map((c) => (
                          <button key={c} onClick={() => { setCityFilter(c); setAreaTouched(true); }} style={{
                            padding: "5px 11px", borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: "pointer",
                            background: cityFilter === c ? "#0B7A3B" : "#F2F2EF",
                            border: `1px solid ${cityFilter === c ? "#0B7A3B" : "#DADAD5"}`,
                            color: cityFilter === c ? "#fff" : "#57574F",
                          }}>{c}</button>
                        ))}
                      </div>
                    </>
                  )}
                </div>

                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 11.5, color: "#6B6B63", marginBottom: 6, fontWeight: 700 }}>施設種別フィルター</div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {levelCounts.map(([lvl, cnt]) => {
                      const on = levelFilter.has(lvl);
                      return (
                        <button key={lvl} onClick={() => {
                          setLevelFilter((s) => { const n = new Set(s); n.has(lvl) ? n.delete(lvl) : n.add(lvl); return n; });
                        }} style={{
                          padding: "5px 11px", borderRadius: 20, fontSize: 12, fontWeight: 700, cursor: "pointer",
                          background: on ? (LEVEL_COLOR[lvl] || "#6B7280") : "#F2F2EF",
                          border: `1px solid ${on ? (LEVEL_COLOR[lvl] || "#6B7280") : "#DADAD5"}`,
                          color: on ? "#fff" : "#6B6B63",
                        }}>{LEVEL_SHORT[lvl] || lvl} {cnt}</button>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 18 }}>
                  {displayList.filter((h) => h.type !== "一般診療所" && h.coordVerified !== false).map((h, i) => (
                    <HospitalCard key={i} h={h} slot={slot} rank={i} distance={h.dist} />
                  ))}
                  {displayList.length === 0 && (
                    <div style={{ textAlign: "center", color: "#8C8C82", padding: 32, fontSize: 13, background: "#fff", borderRadius: 10 }}>
                      該当する施設がありません
                    </div>
                  )}
                  {/* 一般診療所・座標未確定の施設は距離順に混ぜず、参考として末尾に別枠表示 */}
                  {displayList.some((h) => h.type === "一般診療所" || h.coordVerified === false) && (
                    <>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, margin: "10px 0 2px" }}>
                        <div style={{ flex: 1, height: 1, background: "#DADAD5" }} />
                        <span style={{ fontSize: 11.5, color: "#8C8C82", fontWeight: 700 }}>距離表示なし（一般診療所・位置未確認の病院）</span>
                        <div style={{ flex: 1, height: 1, background: "#DADAD5" }} />
                      </div>
                      {displayList.filter((h) => h.type === "一般診療所" || h.coordVerified === false).map((h, i) => (
                        <HospitalCard key={`c-${i}`} h={h} slot={slot} rank={i} distance={null} />
                      ))}
                    </>
                  )}
                </div>
              </>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={goBack} style={{
                flex: 1, padding: 12, background: "#fff", border: "1px solid #DADAD5",
                borderRadius: 10, color: "#57574F", fontSize: 14, cursor: "pointer", fontWeight: 700,
              }}>← 戻る</button>
              <button onClick={reset} style={{
                flex: 2, padding: 12, background: "#B3261E", border: "none",
                borderRadius: 10, color: "#fff", fontSize: 14, cursor: "pointer", fontWeight: 700,
              }}>🔄 最初からやり直す</button>
            </div>
          </div>
        ) : (
          <div style={{ background: "#fff", borderRadius: 14, padding: "22px 18px", border: "1px solid #E4E4E0", boxShadow: "0 4px 18px rgba(0,0,0,.06)", marginTop: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
              <div style={{ background: "#B3261E", color: "#fff", borderRadius: 20, padding: "2px 12px", fontSize: 11, fontWeight: 700 }}>
                STEP {history.length + 1}
              </div>
              <div style={{ height: 2, flex: 1, background: "#EEEEEA" }} />
            </div>
            <div style={{ fontSize: 18, fontWeight: 800, lineHeight: 1.6, color: "#1A1A18", marginBottom: 6 }}>
              {(node.type === "checklist" || node.type === "card" || node.type === "categorySelect") ? node.title : node.q}
            </div>
            {node.type === "card" ? (
              <CardNode
                node={node}
                selections={cardSelections}
                onSelect={selectCardOption}
                onConfirm={goToChecklistResult}
              />
            ) : node.type === "categorySelect" ? (
              <CategorySelectNode
                node={node}
                checked={checklistChecked}
                onToggle={toggleChecklistItem}
                onConfirm={goToCategorySelectResult}
              />
            ) : node.type === "checklist" ? (
              <ChecklistNode
                node={node}
                checked={checklistChecked}
                onToggle={toggleChecklistItem}
                onConfirm={goToChecklistResult}
              />
            ) : (
              <>
                {node.sub && <div style={{ fontSize: 12.5, color: "#6B6B63", marginBottom: 16, lineHeight: 1.6, whiteSpace: "pre-line" }}>{node.sub}</div>}
                <div style={{ display: "flex", flexDirection: "column", gap: 9, marginTop: 16 }}>
                  {node.choices.map((c, i) => (
                    <button key={i} onClick={() => goTo(c)} style={{
                      background: "#F7F7F4", border: "1px solid #E4E4E0", borderRadius: 12, padding: "14px 15px",
                      color: "#2A2A26", fontSize: 15, fontWeight: 600, cursor: "pointer", textAlign: "left",
                      display: "flex", alignItems: "center", gap: 10,
                    }}
                      onMouseEnter={(e) => { e.currentTarget.style.background = "#FBEAEA"; e.currentTarget.style.borderColor = "#EFC2C0"; }}
                      onMouseLeave={(e) => { e.currentTarget.style.background = "#F7F7F4"; e.currentTarget.style.borderColor = "#E4E4E0"; }}
                    >
                      <span style={{
                        width: 26, height: 26, borderRadius: "50%", background: "#FBEAEA",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 12, fontWeight: 800, flexShrink: 0, color: "#B3261E",
                      }}>{i + 1}</span>
                      {c.label}
                    </button>
                  ))}
                </div>
              </>
            )}
            {history.length > 0 && (
              <button onClick={goBack} style={{ marginTop: 14, background: "none", border: "none", color: "#8C8C82", cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>
                ← 前の画面に戻る
              </button>
            )}
          </div>
        )}

        <div style={{ marginTop: 20, padding: "10px 0", borderTop: "1px solid #E4E4E0", fontSize: 10.5, color: "#A3A399", textAlign: "center", lineHeight: 1.9 }}>
          大分県「傷病者の搬送及び受入れの実施基準」（令和7年4月改定）<br />
          搬送先医療機関リスト（令和8年4月1日時点）準拠<br />
          このアプリは補助ツールです。実際の搬送では必ず受入れ照会を行うこと。<br />
          アプリ {__APP_VERSION__}（{__BUILD_DATE__}作成）
        </div>
      </div>
    </div>
  );
}
