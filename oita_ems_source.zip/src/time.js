// 時間帯の判定（平日日中／平日夜間／休日）
// 日本の祝日判定（内閣府の計算式に基づく。振替休日・国民の休日を含む）
const _holidayCache = {};
export function getJapaneseHolidays(year) {
  if (_holidayCache[year]) return _holidayCache[year];
  const h = new Set();
  const pad = (n) => String(n).padStart(2, "0");
  const key = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  const add = (m, d) => h.add(key(year, m, d));

  // 固定日の祝日
  add(1, 1);   // 元日
  add(2, 11);  // 建国記念の日
  add(2, 23);  // 天皇誕生日（令和）
  add(4, 29);  // 昭和の日
  add(5, 3);   // 憲法記念日
  add(5, 4);   // みどりの日
  add(5, 5);   // こどもの日
  add(8, 11);  // 山の日
  add(11, 3);  // 文化の日
  add(11, 23); // 勤労感謝の日

  // 第n月曜日（成人の日・海の日・敬老の日・スポーツの日）
  const nthMonday = (month, n) => {
    let count = 0;
    for (let d = 1; d <= 31; d++) {
      const dt = new Date(year, month - 1, d);
      if (dt.getMonth() !== month - 1) break;
      if (dt.getDay() === 1) { count++; if (count === n) return d; }
    }
    return null;
  };
  add(1, nthMonday(1, 2));   // 成人の日
  add(7, nthMonday(7, 3));   // 海の日
  add(9, nthMonday(9, 3));   // 敬老の日
  add(10, nthMonday(10, 2)); // スポーツの日

  // 春分の日・秋分の日（近似式。1980〜2099年で有効）
  const shunbun = Math.floor(20.8431 + 0.242194 * (year - 1980)) - Math.floor((year - 1980) / 4);
  const shuubun = Math.floor(23.2488 + 0.242194 * (year - 1980)) - Math.floor((year - 1980) / 4);
  add(3, shunbun);
  add(9, shuubun);

  // 国民の休日（前後を祝日に挟まれた平日。日曜は対象外）
  for (let m = 1; m <= 12; m++) {
    for (let d = 1; d <= 31; d++) {
      const dt = new Date(year, m - 1, d);
      if (dt.getMonth() !== m - 1) continue;
      const k = key(year, m, d);
      if (h.has(k) || dt.getDay() === 0) continue;
      const prev = new Date(year, m - 1, d - 1);
      const next = new Date(year, m - 1, d + 1);
      const prevKey = key(prev.getFullYear(), prev.getMonth() + 1, prev.getDate());
      const nextKey = key(next.getFullYear(), next.getMonth() + 1, next.getDate());
      if (h.has(prevKey) && h.has(nextKey)) h.add(k);
    }
  }

  // 振替休日（祝日が日曜の場合、直後の平日で最初に祝日でない日）
  for (const k of Array.from(h)) {
    const [y, m, d] = k.split("-").map(Number);
    if (new Date(y, m - 1, d).getDay() !== 0) continue;
    let next = new Date(y, m - 1, d + 1);
    while (true) {
      const nKey = key(next.getFullYear(), next.getMonth() + 1, next.getDate());
      if (!h.has(nKey)) { h.add(nKey); break; }
      next = new Date(next.getFullYear(), next.getMonth(), next.getDate() + 1);
    }
  }

  _holidayCache[year] = h;
  return h;
}
export function isJapaneseHoliday(jstDate) {
  const y = jstDate.getUTCFullYear(), m = jstDate.getUTCMonth() + 1, d = jstDate.getUTCDate();
  const key = `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  return getJapaneseHolidays(y).has(key);
}

// 年末年始（12/29〜1/3）。多くの医療機関が休診のため休日として扱う（原本に定義はなくアプリの運用上の前提）
export function isYearEndHoliday(jstDate) {
  const m = jstDate.getUTCMonth() + 1, d = jstDate.getUTCDate();
  return (m === 12 && d >= 29) || (m === 1 && d <= 3);
}

export function timeSlot(date) {
  // date.getTime() はUTC基準の絶対時刻なので、端末のタイムゾーン設定に関わらず
  // ここでは常に+9時間するだけでJSTの時・曜日が求まる（getTimezoneOffsetを混ぜると二重補正になる）
  // 前提（原本に定義なし・利用者決定 2026-10-13）：
  //   平日9〜18時、土曜9〜12時＝通常診療時間／平日のそれ以外＝夜間
  //   土曜の午後・夜間、日曜、祝日、年末年始（12/29〜1/3）＝休日
  const jst = new Date(date.getTime() + 9 * 3600 * 1000);
  const day = jst.getUTCDay();
  const hour = jst.getUTCHours();
  if (day === 0 || isJapaneseHoliday(jst) || isYearEndHoliday(jst)) return "holiday";
  if (day === 6) return hour >= 9 && hour < 12 ? "weekday_day" : "holiday";
  if (hour >= 9 && hour < 18) return "weekday_day";
  return "weekday_night";
}
