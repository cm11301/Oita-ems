#!/usr/bin/env python3
"""
搬送先医療機関リスト（PDF）とアプリのデータ（src/data.js）を照合し、差分レポートを出す。
毎年4月の改定版が出たら、このツールで変更点を洗い出してからデータを更新する。

使い方:
    pip install pdfplumber          # 初回のみ
    python3 tools/check_list.py 新しいリスト.pdf
    → tools/out/list_report.md（人が読む差分レポート）と tools/out/list_parsed.json（読み取り結果）

照合する項目:
    掲載施設（追加・削除・並び順）、種別、時間外の可否（○/△/空欄）、入院加療可/初期対応のみ、
    心カテ、対応年齢、小児の年齢帯、軽症リストの平日/休日の可否、各備考
照合しない項目（PDFの結合セルで読み取りが不安定なため）:
    医療圏・市町村（住所は厚生局の医療機関一覧で別途確認する）

注意:
    ・リストはページ見出し「医療機関リスト【…】」で振り分ける（ページ番号には依存しない）
    ・罫線が欠けていて名前を読めない行は「要目視」として報告する（2026年版p57最終行がこの例）
    ・閉院・改称など利用者が確認した例外は tests/fixtures/original_lists.json の closed / renamed を反映して比較する
"""
import json
import os
import re
import sys
import unicodedata

try:
    import pdfplumber
except ImportError:
    sys.exit("pdfplumber が必要です：pip install pdfplumber")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 見出し → リストのキー（上から順に判定。より具体的なものを先に置く）
TITLE_RULES = [
    (r"軽症・小児", "light_peds"),
    (r"軽症.*中枢神経", "light_neuro"),
    (r"軽症.*消化器", "light_digestive"),
    (r"軽症.*呼吸器", "light_respiratory"),
    (r"軽症.*外傷・熱傷・中毒", "light_trauma"),
    (r"小児:疾病:重症対応", "peds_severe"),
    (r"小児:中枢神経", "peds_neuro"),
    (r"小児:呼吸器", "peds_respiratory"),
    (r"小児:循環器", "peds_circulatory"),
    (r"小児:消化器", "peds_digestive"),
    (r"小児:誤飲", "peds_ingestion"),
    (r"外傷・熱傷・中毒:バイタルサイン", "trauma_vital"),
    (r"重症外傷:開放骨折", "trauma_fracture"),
    (r"重症外傷:多発外傷", "trauma_multiple"),
    (r"重症外傷:頭部外傷", "trauma_head"),
    (r"重症外傷:脊椎", "trauma_spine"),
    (r"重症外傷:腹部外傷", "trauma_abdomen"),
    (r"重症外傷:胸部外傷", "trauma_chest"),
    (r"重症外傷:切断指", "trauma_amputation"),
    (r"重症熱傷", "burn"),
    (r"重症中毒", "poison"),
    (r"疾病:バイタルサイン", "vital_severe"),
    (r"急性心筋梗塞", "ami"),
    (r"t-PA", "tpa"),
    (r"脳卒中の疑い", "stroke"),
    (r"急性腹症", "abdomen"),
    (r"呼吸器疾患\(重症\)", "respiratory"),
    (r"婦人科疾患", "gynecology"),
    (r"妊産褥婦", "maternal"),
]


def nfkc(s):
    return unicodedata.normalize("NFKC", s or "")


def norm_name(s):
    return re.sub(r"\s+", "", nfkc(s)).replace("〇", "○")


def raw(s):
    return (s or "").strip()


def mark(s):
    """○→True、△→"partial"、×→False、空欄→None"""
    s = nfkc(raw(s)).replace("〇", "○")
    return {"○": True, "△": "partial", "×": False, "": None}.get(s, s)


def title_to_key(title):
    t = nfkc(title).replace(" ", "").replace("：", ":")
    for pat, key in TITLE_RULES:
        if re.search(pat, t):
            return key
    return None


def parse(pdf_path):
    pdf = pdfplumber.open(pdf_path)
    lists, problems = {}, []
    for pn, page in enumerate(pdf.pages, 1):
        text = (page.extract_text() or "").replace(" ", "")
        m = re.search(r"医療機関リスト【[^】]*】", text)
        if not m:
            continue
        title = m.group(0)
        key = title_to_key(title)
        if not key:
            problems.append(f"p{pn}: 見出し「{title}」をどのリストにも振り分けられない")
            continue
        tables = page.extract_tables()
        if not tables:
            problems.append(f"p{pn}: 表を読み取れない")
            continue
        body = tables[0][2:]
        # 縦に結合したセル（"○\n×" など）を下の空セルへ分配
        for i, r in enumerate(body):
            for j, v in enumerate(r):
                if v and "\n" in v and j not in (2, 4) and i + 1 < len(body) and body[i + 1][j] is None:
                    parts = v.split("\n")
                    if len(parts) == 2:
                        body[i][j], body[i + 1][j] = parts
        admit = "初期対応のみ" not in title
        rows = lists.setdefault(key, [])
        for r in body:
            name = raw((r[2] or "").replace("\n", " "))
            if not name:
                if any(c for j, c in enumerate(r) if j not in (0, 2) and c):
                    problems.append(f"p{pn} {key}: 名前を読めない行あり（罫線欠け）→ 要目視：{r}")
                continue
            d = {"page": pn, "name": re.sub(r"\s+", " ", name), "type": raw((r[3] or "").replace("\n", "")),
                 "note": raw((r[4] or "").replace("\n", ""))}
            if key.startswith("light"):
                d.update(weekdayAvail=mark(r[4]), weekdayNote=raw((r[5] or "").replace("\n", "")),
                         holidayAvail=mark(r[6]), holidayNote=raw((r[7] or "").replace("\n", "")),
                         note=raw((r[8] or "").replace("\n", "")) if len(r) > 8 else "")
            else:
                ah = mark(r[5])
                d.update(afterHours=False if ah is None else ah, extraNote=raw((r[6] or "").replace("\n", "")),
                         admitCapable=admit)
                if key == "ami":
                    d["cath"] = raw(r[6]) or None
                    d["extraNote"] = ""
                if key.startswith("peds"):
                    d["ageBands"] = {k: (nfkc(raw(r[7 + i])).replace("〇", "○") == "○")
                                     for i, k in enumerate(["0-1", "2-4", "5-11", "12-14"])}
                elif len(r) == 9:
                    d["ageMin"], d["ageMax"] = raw(r[7]) or None, raw(r[8]) or None
            # 1つのセルに2施設が入っている行（2026年版の急性心筋梗塞リストに実例あり）
            if "\n" in (r[2] or "") and "\n" in (r[3] or ""):
                problems.append(f"p{pn} {key}: 1行に複数施設が入っている → 要目視：{name}")
            rows.append(d)
    return lists, problems


def load_app():
    src = open(os.path.join(ROOT, "src", "data.js"), encoding="utf-8").read()
    return json.loads(src[src.index("{"):src.rstrip().rstrip(";").rindex("}") + 1])


def same(a, b):
    if isinstance(a, str) or isinstance(b, str):
        return norm_name(a if isinstance(a, str) else json.dumps(a)) == norm_name(b if isinstance(b, str) else json.dumps(b)) \
            or (a in (None, "") and b in (None, ""))
    return a == b


FIELDS = ["type", "note", "afterHours", "extraNote", "admitCapable", "cath", "ageBands", "ageMin", "ageMax",
          "weekdayAvail", "weekdayNote", "holidayAvail", "holidayNote"]


def compare(pdf_lists, app):
    fx_path = os.path.join(ROOT, "tests", "fixtures", "original_lists.json")
    fx = json.load(open(fx_path, encoding="utf-8")) if os.path.exists(fx_path) else {}
    closed = set((fx.get("closed") or {}).keys())
    renamed = {k: v["to"] for k, v in (fx.get("renamed") or {}).items()}
    out = []
    for key in sorted(set(pdf_lists) | set(app)):
        if key == "psychiatric_beds":
            continue
        prow = [r for r in pdf_lists.get(key, []) if r["name"] not in closed]
        for r in prow:
            r["name"] = renamed.get(r["name"], r["name"])
        arow = app.get(key, [])
        pn, an = [norm_name(r["name"]) for r in prow], [norm_name(h["name"]) for h in arow]
        sec = []
        added = [r["name"] for r in prow if norm_name(r["name"]) not in an]
        removed = [h["name"] for h in arow if norm_name(h["name"]) not in pn]
        if key not in pdf_lists:
            sec.append("- **新しいリストに見当たらない**（見出しが変わった可能性）")
        if added:
            sec.append("- 追加（新リストにあり・アプリになし）：" + "、".join(added))
        if removed:
            sec.append("- 削除（アプリにあり・新リストになし）：" + "、".join(removed))
        if not added and not removed and pn != an:
            sec.append("- 掲載施設は同じだが並び順が違う")
        used = set()
        for r in prow:
            idx = [i for i, h in enumerate(arow) if norm_name(h["name"]) == norm_name(r["name"]) and i not in used]
            if not idx:
                continue
            used.add(idx[0])
            h = arow[idx[0]]
            diffs = [f"{f}: {h.get(f)!r} → {r[f]!r}" for f in FIELDS if f in r and not same(h.get(f), r[f])]
            if diffs:
                sec.append(f"- {r['name']}（p{r['page']}）：" + " ／ ".join(diffs))
        if sec:
            out.append(f"### {key}（新リスト {len(prow)}件 ／ アプリ {len(arow)}件）\n" + "\n".join(sec))
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    pdf_lists, problems = parse(sys.argv[1])
    app = load_app()
    diffs = compare(pdf_lists, app)
    os.makedirs(os.path.join(ROOT, "tools", "out"), exist_ok=True)
    json.dump(pdf_lists, open(os.path.join(ROOT, "tools", "out", "list_parsed.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    lines = [f"# 搬送先医療機関リスト照合レポート", f"対象：{os.path.basename(sys.argv[1])}",
             f"読み取ったリスト：{len(pdf_lists)}種類（アプリ {len([k for k in app if k != 'psychiatric_beds'])}種類）", ""]
    lines += ["## 要目視（自動で読めなかった箇所）"] + ([f"- {p}" for p in problems] or ["- なし"]) + [""]
    lines += ["## 差分"] + (diffs or ["- 差分なし"])
    report = "\n".join(lines) + "\n"
    open(os.path.join(ROOT, "tools", "out", "list_report.md"), "w", encoding="utf-8").write(report)
    print(report)


if __name__ == "__main__":
    main()
