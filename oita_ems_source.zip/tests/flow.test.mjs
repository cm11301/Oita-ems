// フロー（判定の流れ）の自動チェック
// 実行：npm test
// 原本：大分県「傷病者の搬送及び受入れの実施基準」搬送先選定フロー（P17〜21）
import { test } from "node:test";
import assert from "node:assert/strict";
import { FLOW } from "../src/flow.js";
import { HOSPITAL_DATA } from "../src/data.js";

const SPECIAL_KEYS = new Set(["__arrest__", "__kakaritsuke__"]);
const DYNAMIC = new Set(["r_trauma_category_pending", "r_adult_category_pending"]);

const kind = (n) => n.type || (n.dataKeys !== undefined ? "result" : "choice");

// あるノードから出ていく行き先をすべて列挙
function edges(id) {
  const n = FLOW[id];
  const out = [];
  if (n.choices) n.choices.forEach((c) => out.push(c.next));
  if (n.onSevere) out.push(n.onSevere);
  if (n.onClear) out.push(n.onClear);
  if (n.onTally) Object.values(n.onTally).forEach((t) => out.push(t));
  return out;
}

test("行き先がすべて存在する（リンク切れなし）", () => {
  for (const id of Object.keys(FLOW)) {
    for (const t of edges(id)) {
      assert.ok(FLOW[t] || DYNAMIC.has(t), `${id} → ${t} が存在しない`);
    }
  }
});

test("すべてのノードに最初の画面からたどり着ける", () => {
  const seen = new Set(["start"]);
  const stack = ["start"];
  while (stack.length) {
    const id = stack.pop();
    for (const t of edges(id)) if (FLOW[t] && !seen.has(t)) { seen.add(t); stack.push(t); }
  }
  const unreachable = Object.keys(FLOW).filter((k) => !seen.has(k));
  assert.deepEqual(unreachable, [], `到達できないノード：${unreachable.join(", ")}`);
});

test("結果ノード・科目選択が参照するリストはすべてデータにある", () => {
  for (const [id, n] of Object.entries(FLOW)) {
    if (n.dataKeys) for (const k of n.dataKeys) if (!SPECIAL_KEYS.has(k)) assert.ok(HOSPITAL_DATA[k]?.length, `${id}: ${k} が空/未定義`);
    if (n.type === "categorySelect") for (const it of n.items) assert.ok(HOSPITAL_DATA[it.id]?.length, `${id}: ${it.id} が空/未定義`);
    if (n.categories) for (const c of n.categories) assert.ok(HOSPITAL_DATA[c.dataKey]?.length, `${id}: ${c.dataKey} が空/未定義`);
  }
});

test("すべてのリストがどこかの結果から使われている", () => {
  const used = new Set();
  for (const n of Object.values(FLOW)) {
    (n.dataKeys || []).forEach((k) => used.add(k));
    if (n.type === "categorySelect") n.items.forEach((it) => used.add(it.id));
    (n.categories || []).forEach((c) => used.add(c.dataKey));
  }
  const unused = Object.keys(HOSPITAL_DATA).filter((k) => !used.has(k));
  assert.deepEqual(unused, [], `どこからも使われないリスト：${unused.join(", ")}`);
});

// ---- 画面操作を模した歩行シミュレーター（App.jsx の分岐処理と同じ規則） ----
// steps の要素：
//   "文字列"            … 選択肢のラベルにこの文字列を含むものを選ぶ
//   { severe: true/false } … カード/チェックリストで重症あり/なし
//   { tally: n }        … カテゴリー集計型（小児カード）で n カテゴリー異常
//   { abnormal: [...] } … 成人一般「重症と判断すべき症状」で異常ありのカテゴリーid
//   { select: [...] }   … 科目選択（複数）
function walk(steps) {
  let id = "start";
  let pending = null;
  const path = [id];
  for (const s of steps) {
    const n = FLOW[id];
    let next;
    if (typeof s === "string") {
      assert.ok(n.choices, `${id} は選択肢ノードではない（"${s}"）`);
      const c = n.choices.filter((c) => c.label.includes(s));
      assert.equal(c.length, 1, `${id} で "${s}" に一致する選択肢が ${c.length} 個`);
      if (c[0].setCategory) pending = c[0].setCategory;
      next = c[0].next;
    } else if ("severe" in s) {
      next = s.severe ? n.onSevere : n.onClear;
    } else if ("tally" in s) {
      next = n.onTally[String(s.tally)];
    } else if ("abnormal" in s) {
      const cats = n.categories.filter((c) => s.abnormal.includes(c.id));
      next = n.onTally[String(cats.length)];
      if (next === "r_adult_category_pending") return { path, keys: cats.map((c) => c.dataKey) };
    } else if ("select" in s) {
      assert.equal(n.type, "categorySelect", `${id} は科目選択ではない`);
      s.select.forEach((x) => assert.ok(n.items.some((it) => it.id === x), `${id} に ${x} がない`));
      return { path, keys: s.select };
    }
    assert.ok(next, `${id} から先が決まらない（${JSON.stringify(s)}）`);
    if (next === "r_trauma_category_pending") return { path, keys: [pending] };
    path.push(next);
    id = next;
    if (FLOW[id].dataKeys !== undefined) return { path, keys: FLOW[id].dataKeys, node: id };
  }
  return { path, at: id };
}
const lands = (steps, keys) => {
  const r = walk(steps);
  assert.deepEqual(r.keys, keys, `経路 ${r.path.join(" → ")} の結果が ${JSON.stringify(r.keys)}（期待 ${JSON.stringify(keys)}）`);
};
const stops = (steps, nodeId) => {
  const r = walk(steps);
  assert.equal(r.at, nodeId, `経路 ${r.path.join(" → ")} が ${r.at} で止まった（期待 ${nodeId}）`);
};

// ---- 成人一般（P17） ----
test("成人：心肺停止 → 直近の救急医療機関", () => lands(["成人一般", "はい"], ["__arrest__"]));
test("成人：外見・バイタル重症 → バイタルサイン等重症対応", () => lands(["成人一般", "いいえ", { severe: true }], ["vital_severe"]));
test("成人：急性冠症候群 → ACSリスト", () => lands(["成人一般", "いいえ", { severe: false }, "急性冠症候群"], ["ami"]));
test("成人：脳卒中 3.5h以内 → t-PA", () => lands(["成人一般", "いいえ", { severe: false }, "脳卒中", "3.5時間以内"], ["tpa"]));
test("成人：脳卒中 3.5h超 → 脳卒中", () => lands(["成人一般", "いいえ", { severe: false }, "脳卒中", "3.5時間超"], ["stroke"]));
test("成人：急性腹症のみ異常 → 急性腹症リストだけ", () =>
  lands(["成人一般", "いいえ", { severe: false }, "その他の重症所見", { abnormal: ["abdomen"] }], ["abdomen"]));
test("成人：呼吸器＋婦人科 → 2リスト", () =>
  lands(["成人一般", "いいえ", { severe: false }, "その他の重症所見", { abnormal: ["respiratory", "gynecology"] }], ["respiratory", "gynecology"]));
test("成人：その他で異常なし → 軽症の科目選択", () =>
  stops(["成人一般", "いいえ", { severe: false }, "その他の重症所見", { abnormal: [] }], "adult_light_category_q"));
test("成人：軽症 → 科目選択（4科目すべて選べる）", () => {
  lands(["成人一般", "いいえ", { severe: false }, "軽症", { select: ["light_neuro", "light_digestive", "light_respiratory", "light_trauma"] }],
    ["light_neuro", "light_digestive", "light_respiratory", "light_trauma"]);
});

// ---- 小児（P18） ----
test("小児：心肺停止 → 直近", () => lands(["小児", "はい"], ["__arrest__"]));
test("小児：外傷 → 外傷・熱傷・中毒の選択へ", () => stops(["小児", "いいえ", "はい（外傷"], "trauma_type_q"));
test("小児：3カテゴリー異常 → 重症対応", () => lands(["小児", "いいえ", "いいえ（疾病", { tally: 3 }], ["peds_severe"]));
test("小児：1カテゴリー異常 → 疑い疾患分類の選択（原本カードP12）", () =>
  stops(["小児", "いいえ", "いいえ（疾病", { tally: 1 }], "peds_suspect_category_q"));
test("小児：重症疑い・呼吸器を選ぶ → 呼吸器の重症疑いリストだけ", () =>
  lands(["小児", "いいえ", "いいえ（疾病", { tally: 2 }, { select: ["peds_respiratory"] }], ["peds_respiratory"]));
test("小児：重症疑いの分類は原本の5つ", () =>
  assert.deepEqual(FLOW.peds_suspect_category_q.items.map((i) => i.id), ["peds_neuro", "peds_respiratory", "peds_circulatory", "peds_digestive", "peds_ingestion"]));
test("小児：異常なし → 軽症・小児", () => lands(["小児", "いいえ", "いいえ（疾病", { tally: 0 }], ["light_peds"]));

// ---- 妊産褥婦（P19・P20注） ----
test("妊産褥婦：心肺停止 → 直近", () => lands(["妊産褥婦", "はい"], ["__arrest__"]));
test("妊産褥婦：交通外傷で腹部打撲等あり → 妊産褥婦リスト", () => lands(["妊産褥婦", "いいえ", "いいえ", "あり", "認める"], ["maternal"]));
test("妊産褥婦：外傷あり・注記非該当 → 外傷の種類選択（心肺停止は再確認しない）", () =>
  stops(["妊産褥婦", "いいえ", "いいえ", "あり", "認めない"], "trauma_type_q"));
test("妊産褥婦：重症 → 妊産褥婦リスト", () => lands(["妊産褥婦", "いいえ", "いいえ", "なし", { severe: true }], ["maternal"]));

// ---- 外傷・熱傷・中毒（P20） ----
const T = ["外傷・熱傷・中毒", "いいえ", "認めない"];
test("外傷入口：心肺停止 → 直近", () => lands(["外傷・熱傷・中毒", "はい"], ["__arrest__"]));
test("外傷入口：妊産婦の交通外傷（注記該当） → 妊産褥婦リスト", () => lands(["外傷・熱傷・中毒", "いいえ", "認める"], ["maternal"]));
test("外傷：外見・バイタル重症 → バイタルサイン等重症対応", () => lands([...T, "外傷", { severe: true }], ["trauma_vital"]));
test("外傷：全身観察・受傷機転で該当 → バイタルサイン等重症対応", () =>
  lands([...T, "外傷", { severe: false }, { severe: true }], ["trauma_vital"]));
const LOCAL = { 開放骨折: "trauma_fracture", 多発外傷: "trauma_multiple", 頭部外傷: "trauma_head", 脊椎: "trauma_spine", 腹部外傷: "trauma_abdomen", 胸部外傷: "trauma_chest", 切断指: "trauma_amputation" };
for (const [label, key] of Object.entries(LOCAL)) {
  test(`外傷：全身観察該当なし＋「${label}」 → ${key}（軽症に落ちない）`, () =>
    lands([...T, "外傷", { severe: false }, { severe: false }, label], [key]));
}
test("外傷：重症なし・15歳以上 → 軽症外傷", () => lands([...T, "外傷", { severe: false }, { severe: false }, "該当なし", "15歳以上"], ["light_trauma"]));
test("外傷：重症なし・15歳未満 → 軽症・小児", () => lands([...T, "外傷", { severe: false }, { severe: false }, "該当なし", "15歳未満"], ["light_peds"]));
test("熱傷：表面重症 → バイタルサイン等重症対応", () => lands([...T, "熱傷", { severe: true }], ["trauma_vital"]));
test("熱傷：裏面重症 → 重症熱傷", () => lands([...T, "熱傷", { severe: false }, { severe: true }], ["burn"]));
test("中毒：表面重症 → バイタルサイン等重症対応", () => lands([...T, "中毒", { severe: true }], ["trauma_vital"]));
test("中毒：裏面重症 → 重症中毒", () => lands([...T, "中毒", { severe: false }, { severe: true }], ["poison"]));
test("中毒：重症なし → 軽症（年齢で分岐）", () => stops([...T, "中毒", { severe: false }, { severe: false }], "trauma_age_q"));

// ---- 精神疾患（P21） ----
test("精神：外見・バイタル重症 → 疾病バイタル重症", () => lands(["精神疾患", "外見・バイタル"], ["vital_severe"]));
test("精神：急性冠症候群 → ACS", () => lands(["精神疾患", "急性冠症候群"], ["ami"]));
test("精神：主訴・局所状態の重症 → 成人一般のチェック画面（該当科目だけ表示）", () =>
  lands(["精神疾患", "主訴・局所状態", { abnormal: ["abdomen"] }], ["abdomen"]));
test("精神：心肺停止 → 直近", () => lands(["精神疾患", "心肺停止"], ["__arrest__"]));
test("精神：身体症状なし・入院治療必要 → 精神病床のある救急医療機関", () => lands(["精神疾患", "いずれもなし", "あり"], ["psychiatric_beds"]));
test("精神：身体症状なし・精神症状なし → 成人一般の軽症", () => stops(["精神疾患", "いずれもなし", "なし"], "adult_light_category_q"));
test("精神：小児等 → 各フローへ", () => stops(["精神疾患", "小児・妊産褥婦", "外傷"], "trauma_type_q"));

// ---- 外傷観察カード裏面（原本どおり28項目） ----
test("外傷観察カード裏面：全身観察16項目＋受傷機転12項目（原本どおり）", () => {
  const items = FLOW.trauma_body_check.redItems;
  assert.equal(items.filter((i) => i.label.startsWith("［全身観察］")).length, 16);
  assert.equal(items.filter((i) => i.label.startsWith("［受傷機転］")).length, 12);
  assert.ok(items.some((i) => i.label.includes("多指切断（手指2本以上、足趾3本以上）")));
  assert.ok(items.some((i) => i.label === "［全身観察］四肢麻痺"));
});

// ---- 観察カードの赤枠・青枠（原本P11〜16と照合済み 2026-10-13） ----
const tiers = (id, t) => FLOW[id].rows.flatMap((r) => r.options.filter((o) => o.tier === t).map((o) => o.label)).sort();
test("成人カード：赤枠8項目・青枠7項目が原本どおり", () => {
  assert.deepEqual(tiers("adult_vital", "red"), ["冷汗", "感ぜず", "異常（呼吸）", "無表情・うつろ", "総頸触れず", "胸部挙上不十分", "蒼白・チアノーゼ", "虚脱"].sort());
  assert.deepEqual(tiers("adult_vital", "blue"), ["100・200・300", "10回/分未満・30回/分以上", "120回/分以上", "50回/分未満", "90%未満", "収縮期90mmHg未満", "意識障害進行"].sort());
});
test("外傷カード表面：青枠なし、赤枠は原本の17項目", () => {
  assert.deepEqual(tiers("trauma_q", "blue"), []);
  assert.deepEqual(tiers("trauma_q", "red"), ["100・200・300","10未満または30以上（成人）","15未満または35以上（乳幼児）","50未満または120以上（成人）","80未満または150以上（乳幼児）","90%未満","90mmHg未満・200mmHg以上","冷汗","左右差（あり）","感ぜず","測定不能","無表情・うつろ","異常（呼吸）","総頸触れず","胸部挙上不十分","蒼白・チアノーゼ","虚脱"].sort());
});
test("妊産褥婦カード：赤色は原本の13項目（1つで重症）", () =>
  assert.deepEqual(tiers("maternal_severe_q", "red"), ["10回/分未満・30回/分以上","1以上","30・100・200・300","50回/分未満・150回/分以上","90%未満","90mmHg未満・200mmHg以上","あり","あり","あり（1,000ml以上）","あり（呼吸）","冷汗・皮膚蒼白・意識レベル低下・その他","感ぜず","触れず"].sort()));
test("熱傷・中毒の表面：赤枠8・青枠7、青は2つ以上で重症", () => {
  for (const id of ["burn_front_check", "poison_front_check"]) {
    assert.equal(FLOW[id].redItems.length, 8); assert.equal(FLOW[id].blueItems.length, 7); assert.equal(FLOW[id].blueThreshold, 2);
  }
});
test("外傷カード裏面の文言が原本どおり（腹部の膨瘤）", () =>
  assert.ok(FLOW.trauma_body_check.redItems.some((i) => i.label === "［全身観察］腹部の膨瘤、筋性防御")));
