// 時間帯の判定（平日日中／平日夜間／休日）の自動チェック
import { test } from "node:test";
import assert from "node:assert/strict";
import { timeSlot } from "../src/time.js";

// 日本時間で日時を作る
const jst = (y, m, d, h = 12, mi = 0) => new Date(Date.UTC(y, m - 1, d, h - 9, mi));

test("平日の日中・夜間・境目", () => {
  assert.equal(timeSlot(jst(2026, 10, 14, 9, 0)), "weekday_day");
  assert.equal(timeSlot(jst(2026, 10, 14, 17, 59)), "weekday_day");
  assert.equal(timeSlot(jst(2026, 10, 14, 18, 0)), "weekday_night");
  assert.equal(timeSlot(jst(2026, 10, 14, 8, 59)), "weekday_night");
});
test("土曜は9〜12時だけ通常診療時間、それ以外と日曜は休日", () => {
  assert.equal(timeSlot(jst(2026, 10, 17, 8, 59)), "holiday");
  assert.equal(timeSlot(jst(2026, 10, 17, 9, 0)), "weekday_day");
  assert.equal(timeSlot(jst(2026, 10, 17, 11, 59)), "weekday_day");
  assert.equal(timeSlot(jst(2026, 10, 17, 12, 0)), "holiday");
  assert.equal(timeSlot(jst(2026, 10, 17, 20, 0)), "holiday");
  assert.equal(timeSlot(jst(2026, 10, 18, 10, 0)), "holiday");
});
test("土曜でも祝日・年末年始なら午前も休日", () => {
  assert.equal(timeSlot(jst(2027, 1, 2, 10)), "holiday");   // 年始の土曜
  assert.equal(timeSlot(jst(2029, 5, 5, 10)), "holiday");   // こどもの日（2029年は土曜）
  assert.equal(timeSlot(jst(2028, 4, 29, 10)), "holiday");  // 昭和の日（2028年は土曜）
});
test("祝日・振替休日・国民の休日", () => {
  assert.equal(timeSlot(jst(2026, 10, 12)), "holiday"); // スポーツの日
  assert.equal(timeSlot(jst(2026, 11, 3)), "holiday");  // 文化の日
  assert.equal(timeSlot(jst(2026, 9, 22)), "holiday");  // 国民の休日（敬老の日と秋分の日の間）
  assert.equal(timeSlot(jst(2026, 5, 6)), "holiday");   // 振替休日（5/3が日曜）
});
test("年末年始（12/29〜1/3）は休日", () => {
  for (const [y, m, d] of [[2026, 12, 29], [2026, 12, 30], [2026, 12, 31], [2027, 1, 1], [2027, 1, 2], [2027, 1, 3]])
    assert.equal(timeSlot(jst(y, m, d, 10)), "holiday", `${y}/${m}/${d}`);
  assert.equal(timeSlot(jst(2026, 12, 28, 10)), "weekday_day");
  assert.equal(timeSlot(jst(2027, 1, 4, 10)), "weekday_day");
});
test("端末の時計が日本時間でなくても、日本時間で判定する", () => {
  // 2026-12-28 23:30 JST（平日夜間）＝ UTC 14:30
  assert.equal(timeSlot(new Date("2026-12-28T14:30:00Z")), "weekday_night");
  // 2026-12-29 00:30 JST（年末年始）＝ UTC 12-28 15:30
  assert.equal(timeSlot(new Date("2026-12-28T15:30:00Z")), "holiday");
});
