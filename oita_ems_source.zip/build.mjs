// ビルド：npm run build
// src/ をバンドルし、GitHub Pages にそのまま置けるファイル一式を dist/ に作る。
//   dist/oita_ems.html        … アプリ本体（GitHubには「oita ems.html」の名前で置く）
//   dist/sw.js                … オフライン対応（サービスワーカー）
//   dist/manifest.webmanifest … ホーム画面に追加したときの設定
//   dist/icon-180.png, icon-512.png … ホーム画面のアイコン
import { build } from "esbuild";
import fs from "fs";

const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const VERSION = "v" + pkg.version;
const now = new Date(Date.now() + 9 * 3600 * 1000); // 日本時間
const BUILD_DATE = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-${String(now.getUTCDate()).padStart(2, "0")}`;

const result = await build({
  entryPoints: ["src/index.jsx"],
  bundle: true,
  minify: true,
  format: "esm",
  jsx: "automatic",
  loader: { ".jpg": "dataurl" },
  define: { __APP_VERSION__: JSON.stringify(VERSION), __BUILD_DATE__: JSON.stringify(BUILD_DATE) },
  write: false,
  logLevel: "warning",
});
const js = result.outputFiles[0].text;

const html = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>大分県救急搬送先選定支援アプリ</title>
<meta name="theme-color" content="#B3261E" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-title" content="搬送先選定" />
<link rel="manifest" href="manifest.webmanifest" />
<link rel="apple-touch-icon" href="icon-180.png" />
<style>
  html, body { margin:0; padding:0; }
  #root { min-height:100vh; }
</style>
</head>
<body>
<div id="root"></div>
<script type="module">
${js}</script>
</body>
</html>
`;

fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/oita_ems.html", html);
fs.writeFileSync("dist/sw.js", fs.readFileSync("src/sw.js", "utf8").replace("__CACHE_NAME__", `oita-ems-${VERSION}-${BUILD_DATE}`));
for (const f of ["manifest.webmanifest", "icon-180.png", "icon-512.png"]) fs.copyFileSync(`public/${f}`, `dist/${f}`);
console.log(`dist/oita_ems.html (${(html.length / 1024 / 1024).toFixed(2)} MB) ${VERSION} ${BUILD_DATE} ＋ sw.js / manifest / icons`);
