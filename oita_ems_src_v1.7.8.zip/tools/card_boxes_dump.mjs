// 観察カードの画像とタップ枠を tools/out/ に書き出す（check_card_boxes.py が使う）
import fs from "node:fs";
const { CARD_IMAGES } = await import("../src/assets/cardImages.js");
const { FLOW } = await import("../src/flow.js");
fs.mkdirSync(new URL("./out/", import.meta.url), { recursive: true });
const out = {};
for (const [id, n] of Object.entries(FLOW)) if (n.cardImage && CARD_IMAGES[n.cardImage]) {
  fs.writeFileSync(new URL(`./out/card_${n.cardImage}.jpg`, import.meta.url), Buffer.from(CARD_IMAGES[n.cardImage], "base64"));
  out[id] = { img: n.cardImage, opts: n.rows.flatMap((r) => r.options.filter((o) => o.box).map((o) => ({ row: r.label, ...o }))) };
}
fs.writeFileSync(new URL("./out/cards_boxes.json", import.meta.url), JSON.stringify(out));
