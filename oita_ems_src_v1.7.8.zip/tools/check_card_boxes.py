#!/usr/bin/env python3
"""観察カードのタップ枠の四辺が、原本画像の罫線（黒）または赤枠・青枠の線の上にあるかを確認する。
使い方: node tools/card_boxes_dump.mjs && python3 tools/check_card_boxes.py （要 Pillow）
ずれている枠だけを表示する。何も出なければ全て線の上にある。"""
import json, os
from PIL import Image
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
d = json.load(open(os.path.join(OUT, "cards_boxes.json"), encoding="utf-8"))
for k, v in d.items():
    im = Image.open(os.path.join(OUT, f"card_{v['img']}.jpg")).convert("RGB"); W, H = im.size; px = im.load()
    def line_px(p):
        r, g, b = p
        return (r + g + b) / 3 < 130 or (r > 170 and g < 100 and b < 100) or (b > 130 and r < 100)
    def edge(horizontal, c, a1, a2):
        best = 0
        for off in range(-5, 6):
            n = t = 0
            for a in range(int(a1) + 4, int(a2) - 4):
                x, y = (a, int(c) + off) if horizontal else (int(c) + off, a)
                if 0 <= x < W and 0 <= y < H:
                    t += 1; n += line_px(px[x, y])
            if t: best = max(best, n / t)
        return best
    for o in v["opts"]:
        b = o["box"]; x1, y1, x2, y2 = b["x1"] * W / 100, b["y1"] * H / 100, b["x2"] * W / 100, b["y2"] * H / 100
        e = {"上": edge(True, y1, x1, x2), "下": edge(True, y2, x1, x2), "左": edge(False, x1, y1, y2), "右": edge(False, x2, y1, y2)}
        bad = [f"{s}{r:.0%}" for s, r in e.items() if r < 0.6]
        if bad: print(k, o["tier"], o["row"], o["label"], "線から外れている辺:", bad)

# 2) 通常項目の枠の内側を罫線が横切っていないか（＝1つの枠が2つの升目にまたがっていないか）
#    原本で意図的に1項目としているもの（外傷の「／」2欄、かかりつけ医の行）は除外
ALLOW = {("trauma_q", "t_bp_lr_na"), ("maternal_severe_q", "m_kk_yes"), ("maternal_severe_q", "m_kk_no")}
for k, v in d.items():
    im = Image.open(os.path.join(OUT, f"card_{v['img']}.jpg")).convert("RGB"); W, H = im.size; px = im.load()
    dark = lambda p: sum(p) / 3 < 130
    for o in v["opts"]:
        if o["tier"] in ("red", "blue") or (k, o["id"]) in ALLOW: continue
        b = o["box"]; x1, y1, x2, y2 = [int(b["x1"] * W / 100), int(b["y1"] * H / 100), int(b["x2"] * W / 100), int(b["y2"] * H / 100)]
        hits = []
        for y in range(y1 + 6, y2 - 5):
            if sum(dark(px[x, y]) for x in range(x1 + 3, x2 - 3)) / max(1, x2 - x1 - 6) > 0.85: hits.append(("横", round(y / H * 100, 1)))
        for x in range(x1 + 6, x2 - 5):
            if sum(dark(px[x, y]) for y in range(y1 + 3, y2 - 3)) / max(1, y2 - y1 - 6) > 0.85: hits.append(("縦", round(x / W * 100, 1)))
        if hits: print(k, o["row"], o["label"], "枠の内側を罫線が横切っている:", sorted(set(hits)))
