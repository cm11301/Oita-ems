// 医療機関データの自動チェック
// 実行：npm test
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { HOSPITAL_DATA } from "../src/data.js";

const FIXTURE = JSON.parse(fs.readFileSync(new URL("./fixtures/original_lists.json", import.meta.url), "utf8"));
// 原本に載っているが閉院が確認された施設は除いて比較する
const CLOSED = new Set(Object.keys(FIXTURE.closed || {}));
// 改称・病院化などで名前が変わった施設は新しい名前に読み替える
const RENAMED = Object.fromEntries(Object.entries(FIXTURE.renamed || {}).map(([a, b]) => [a, b.to]));
const ORIGINAL = Object.fromEntries(Object.entries(FIXTURE.lists).map(([k, v]) => [k, v.filter((n) => !CLOSED.has(n)).map((n) => RENAMED[n] || n)]));
const nz = (s) => (s || "").normalize("NFKC").replace(/\s+/g, "");

test("掲載施設と並び順が原本（搬送先医療機関リスト）と一致する", () => {
  assert.deepEqual(
    Object.keys(HOSPITAL_DATA).filter((k) => k !== "psychiatric_beds").sort(),
    Object.keys(ORIGINAL).sort(),
    "リストの種類が原本と違う"
  );
  for (const [k, names] of Object.entries(ORIGINAL)) {
    const app = HOSPITAL_DATA[k].map((h) => nz(h.name));
    const org = names.map(nz);
    const missing = org.filter((n) => !app.includes(n));
    const extra = app.filter((n) => !org.includes(n));
    assert.deepEqual({ missing, extra }, { missing: [], extra: [] }, `${k}：原本との差`);
    assert.deepEqual(app, org, `${k}：並び順が原本と違う`);
  }
});

test("精神病床のある救急医療機関は原本P21の3施設", () => {
  assert.deepEqual(HOSPITAL_DATA.psychiatric_beds.map((h) => h.name).sort(),
    ["大分県立病院", "大分大学医学部附属病院", "別府医療センター"].sort());
});

test("値の形が正しい", () => {
  for (const [k, list] of Object.entries(HOSPITAL_DATA)) {
    for (const h of list) {
      const where = `${k} / ${h.name}`;
      assert.ok(h.name && h.city && h.area && h.type, `${where}：名前・市町村・医療圏・種別のどれかが空`);
      if (k.startsWith("light_")) {
        // null＝原本の欄が空欄（記載なし）。×（不可）は false
        for (const f of ["weekdayAvail", "holidayAvail"]) assert.ok([true, false, "partial", null].includes(h[f]), `${where}：${f}=${JSON.stringify(h[f])}`);
      } else {
        assert.ok([true, false, "partial"].includes(h.afterHours), `${where}：afterHours=${JSON.stringify(h.afterHours)}`);
        assert.ok([true, false].includes(h.admitCapable), `${where}：admitCapable=${JSON.stringify(h.admitCapable)}`);
      }
      assert.ok([null, undefined, "○", "△"].includes(h.cath), `${where}：cath=${JSON.stringify(h.cath)}`);
      for (const f of ["note", "extraNote", "weekdayNote", "holidayNote"]) {
        if (h[f] != null) assert.ok(!/^[○△×〇]+$/.test(h[f]), `${where}：${f} に記号だけが入っている（${h[f]}）`);
      }
    }
  }
});

test("病院（診療所以外）は座標があり、九州の範囲内", () => {
  for (const [k, list] of Object.entries(HOSPITAL_DATA)) {
    for (const h of list) {
      if (h.type === "一般診療所" || h.coordVerified === false) continue;
      assert.ok(typeof h.lat === "number" && typeof h.lng === "number", `${k} / ${h.name}：座標なし（確認できない場合は coordVerified:false にする）`);
      assert.ok(h.lat > 32.5 && h.lat < 34.0 && h.lng > 130.3 && h.lng < 132.2, `${k} / ${h.name}：座標が範囲外 ${h.lat},${h.lng}`);
    }
  }
});

test("同じ施設は、どのリストでも住所・座標・市町村が同じ", () => {
  const seen = new Map();
  for (const [k, list] of Object.entries(HOSPITAL_DATA)) {
    for (const h of list) {
      const sig = JSON.stringify([h.addr, h.lat, h.lng, h.city, h.coordVerified ?? null]);
      if (!seen.has(h.name)) seen.set(h.name, { sig, k });
      else assert.equal(sig, seen.get(h.name).sig, `${h.name}：${seen.get(h.name).k} と ${k} で住所/座標が違う`);
    }
  }
});

test("市町村と医療圏の対応が一貫している（全県・県外の区分を除く）", () => {
  const m = new Map();
  for (const list of Object.values(HOSPITAL_DATA)) {
    for (const h of list) {
      if (h.area === "全県") continue;
      if (!m.has(h.city)) m.set(h.city, h.area);
      else assert.equal(h.area, m.get(h.city), `${h.city}：医療圏が ${m.get(h.city)} と ${h.area} に分かれている（${h.name}）`);
    }
  }
});

test("住所が市町村と食い違っていない", () => {
  for (const list of Object.values(HOSPITAL_DATA)) {
    for (const h of list) {
      if (!h.addr || h.area === "県外") continue;
      const city = h.city.replace(/（.*）/, "");
      assert.ok(h.addr.includes(city), `${h.name}：市町村=${h.city} なのに住所=${h.addr}`);
    }
  }
});

test("一般診療所は座標を持たない（距離を出さない方針）", () => {
  for (const [k, list] of Object.entries(HOSPITAL_DATA)) {
    for (const h of list) if (h.type === "一般診療所") assert.ok(h.lat == null && h.lng == null, `${k} / ${h.name}：診療所に座標が入っている`);
  }
});

test("原本と実住所で市町村が違う施設は実住所（利用者確認済み）", () => {
  // 原本（搬送先医療機関リスト）は「大分市」と記載。厚生局の医療機関一覧（R8.9.1）では下記の住所のみ。
  const EXPECT = { "時枝内科医院": "宇佐市", "新こどもクリニック": "由布市" };
  for (const list of Object.values(HOSPITAL_DATA)) for (const h of list) if (EXPECT[h.name]) assert.equal(h.city, EXPECT[h.name], h.name);
});

test("閉院した施設は載っていない", () => {
  for (const list of Object.values(HOSPITAL_DATA)) for (const h of list) assert.ok(!CLOSED.has(h.name), `${h.name} は閉院`);
});

test("全施設に電話番号（代表）があり、形が正しい", () => {
  for (const [k, list] of Object.entries(HOSPITAL_DATA)) {
    for (const h of list) assert.match(h.tel || "", /^0\d{1,4}-\d{1,4}-\d{3,4}$/, `${k} / ${h.name}：電話番号 ${h.tel}`);
  }
});
test("同じ施設はどのリストでも電話番号が同じ", () => {
  const m = new Map();
  for (const list of Object.values(HOSPITAL_DATA)) for (const h of list) {
    if (!m.has(h.name)) m.set(h.name, h.tel); else assert.equal(h.tel, m.get(h.name), h.name);
  }
});

// ---- 診療科（参考情報・九州厚生局 R8.9.1）----
import { DEPTS, DEPT_OF } from "../src/depts.js";
test("診療科データ：県内の全施設にあり、キーが正しい（県外は未収録）", () => {
  const keys = new Set(DEPTS.map(([k]) => k));
  for (const list of Object.values(HOSPITAL_DATA)) for (const h of list) {
    if (h.area === "県外") { assert.ok(!DEPT_OF[h.name], `${h.name}：県外なのに診療科データあり`); continue; }
    assert.ok(DEPT_OF[h.name] && DEPT_OF[h.name].length > 0, `${h.name}：診療科データなし`);
    for (const k of DEPT_OF[h.name]) assert.ok(keys.has(k), `${h.name}：不明な診療科キー ${k}`);
  }
  const names = new Set(Object.values(HOSPITAL_DATA).flat().map((h) => h.name));
  for (const n of Object.keys(DEPT_OF)) assert.ok(names.has(n), `診療科データに余分な施設：${n}`);
});
test("診療科データ：代表例（大学・県立は主要科すべて、永冨は神経内科・脳外科）", () => {
  for (const n of ["大分大学医学部附属病院", "大分県立病院"])
    for (const k of ["neuro_med", "neurosurg", "cardio", "cvs", "gi", "surg", "resp", "ortho", "peds", "obgyn", "psy"]) assert.ok(DEPT_OF[n].includes(k), `${n}：${k}`);
  assert.ok(DEPT_OF["永冨脳神経外科病院"].includes("neuro_med") && DEPT_OF["永冨脳神経外科病院"].includes("neurosurg"));
});
