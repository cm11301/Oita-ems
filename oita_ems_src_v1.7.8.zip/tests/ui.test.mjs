// 画面操作の自動チェック（ビルド済みの dist/oita_ems.html をスマホ幅で実際に操作する）
// 実行：npm test（先に npm run build が走る）
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { chromium } from "playwright";
import path from "node:path";
import fs from "node:fs";

const FILE = path.resolve("dist/oita_ems.html");
let browser;
before(async () => {
  assert.ok(fs.existsSync(FILE), "dist/oita_ems.html がない（npm run build を先に）");
  const exe = fs.existsSync("/opt/pw-browsers/chromium") ? "/opt/pw-browsers/chromium" : undefined;
  browser = await chromium.launch(exe ? { executablePath: exe } : {});
});
after(async () => browser && (await browser.close()));

// 大分市役所付近を現在地とする
async function openApp() {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    geolocation: { latitude: 33.2381, longitude: 131.6126 },
    permissions: ["geolocation"],
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE);
  return { page, errors, ctx };
}
const tap = async (page, text) => {
  await page.locator("button", { hasText: text }).first().click();
  await page.waitForTimeout(150);
};

test("外傷：脊椎（髄）損傷 → 脊椎損傷リストが距離順で出る", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "外傷・熱傷・中毒");
  await tap(page, "いいえ");
  await tap(page, "認めない");
  await tap(page, "外傷");
  await tap(page, "この内容で判定する"); // 外見・バイタル：該当なし
  await tap(page, "この内容で判定する"); // 全身観察・受傷機転：該当なし
  await tap(page, "脊椎（髄）損傷");
  await page.waitForTimeout(800);
  const body = await page.innerText("body");
  assert.match(body, /重症外傷：脊椎（髄）損傷対応/);
  assert.match(body, /現在地から距離順/);
  assert.match(body, /📍\d+(\.\d)?km/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("外傷入口：妊産婦の交通外傷 → 妊産褥婦リスト", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "外傷・熱傷・中毒");
  await tap(page, "いいえ");
  await tap(page, "認める");
  await page.waitForTimeout(500);
  assert.match(await page.innerText("body"), /妊産褥婦対応/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("成人：軽症 → 科目を2つ選ぶと2リストが出る", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "成人一般");
  await tap(page, "いいえ");
  await tap(page, "この内容で判定する");
  await tap(page, "上記いずれも該当しない");
  await tap(page, "中枢神経疾患");
  await tap(page, "外傷・熱傷・中毒");
  await tap(page, "この内容で医療機関を表示");
  await page.waitForTimeout(500);
  const body = await page.innerText("body");
  assert.match(body, /軽症：中枢神経疾患.*・外傷・熱傷・中毒/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("精神：主訴・局所状態の重症 → 成人一般のチェック画面", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "精神疾患");
  await tap(page, "主訴・局所状態による重症");
  await page.waitForTimeout(300);
  assert.match(await page.innerText("body"), /重症と判断すべき症状/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("時間外の備考が表示される（例：永冨脳神経外科病院「24時間365日対応可能」）", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "成人一般");
  await tap(page, "いいえ");
  await tap(page, "この内容で判定する");
  await tap(page, "脳卒中の疑い");
  await tap(page, "3.5時間以内");
  await page.waitForTimeout(800);
  // 時間帯の絞り込みで隠れていれば「対応可のみ表示」を解除
  const toggle = page.locator("button", { hasText: "対応可のみ表示" });
  if (await toggle.count()) { await toggle.first().click(); await page.waitForTimeout(300); }
  assert.match(await page.innerText("body"), /24時間365日対応可能/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

// ---- オフライン：一度開いたら圏外でも開ける ----
import http from "node:http";
test("オフライン：一度開いた後は圏外でも起動でき、圏外の表示が出る", async () => {
  const files = {
    "/oita%20ems.html": ["dist/oita_ems.html", "text/html; charset=utf-8"],
    "/sw.js": ["dist/sw.js", "text/javascript"],
    "/manifest.webmanifest": ["dist/manifest.webmanifest", "application/manifest+json"],
    "/icon-180.png": ["dist/icon-180.png", "image/png"],
    "/icon-512.png": ["dist/icon-512.png", "image/png"],
  };
  const server = http.createServer((req, res) => {
    const f = files[req.url.split("?")[0]];
    if (!f) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { "Content-Type": f[1] });
    res.end(fs.readFileSync(f[0]));
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const url = `http://localhost:${server.address().port}/oita%20ems.html`;
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(url);
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload(); // サービスワーカーの管理下で読み直して保存させる
  await page.waitForTimeout(500);
  server.close();
  await ctx.setOffline(true);
  await page.reload();
  await page.waitForTimeout(500);
  const body = await page.innerText("body");
  assert.match(body, /傷病者の区分を選択してください/, "圏外で起動できない");
  assert.match(body, /圏外：端末に保存した版/, "圏外の表示が出ない");
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("成人：自動判定は該当なしでも『総合判断で重症』でバイタル重症リストへ", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "成人一般");
  await tap(page, "いいえ");
  await tap(page, "総合判断で重症とする");
  await page.waitForTimeout(500);
  assert.match(await page.innerText("body"), /疾病：バイタルサイン等重症対応/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("時間帯を手動で『休日・年末年始』に切り替えられる", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(500);
  await page.selectOption('select[aria-label="時間帯の切替"]', "holiday");
  await page.waitForTimeout(200);
  const body = await page.innerText("body");
  assert.match(body, /休日・診療時間外/);
  assert.match(body, /手動で切替中/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("病院カードに電話（tel:）と地図（Googleマップ経路）のボタンがある", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(800);
  const tel = await page.locator('a[href^="tel:"]').first().getAttribute("href");
  assert.match(tel, /^tel:0\d{9,10}$/);
  const map = await page.locator('a[aria-label$="を地図で開く"]').first().getAttribute("href");
  assert.match(map, /^https:\/\/www\.google\.com\/maps\/dir\/\?api=1&destination=/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("現在地（日出町）から医療圏を自動選択する", async () => {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    geolocation: { latitude: 33.3726, longitude: 131.5326 },
    permissions: ["geolocation"],
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("file://" + FILE);
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(800);
  const body = await page.innerText("body");
  assert.match(body, /現在地から自動選択/);
  const active = await page.locator("button", { hasText: "別杵速見" }).first().evaluate((el) => getComputedStyle(el).backgroundColor);
  assert.equal(active, "rgb(17, 85, 204)", "別杵速見が選択状態になっていない");
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("位置情報が使えないときは従来どおり大分医療圏", async () => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  await page.goto("file://" + FILE);
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(800);
  const active = await page.locator("button", { hasText: "大分" }).filter({ hasNotText: "全" }).first().evaluate((el) => getComputedStyle(el).backgroundColor);
  assert.equal(active, "rgb(17, 85, 204)");
  await ctx.close();
});

test("狭い画面（幅308・320）でも電話・地図ボタンが切れず1行に並ぶ", async () => {
  for (const width of [308, 320]) {
    const ctx = await browser.newContext({ viewport: { width, height: 700 }, geolocation: { latitude: 33.2381, longitude: 131.6126 }, permissions: ["geolocation"] });
    const page = await ctx.newPage();
    await page.goto("file://" + FILE);
    await tap(page, "精神疾患");
    await tap(page, "外見・バイタルサインによる重症");
    await page.locator("button", { hasText: "全て" }).first().click();
    await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      let clipped = 0, wrapped = 0, n = 0;
      for (const a of document.querySelectorAll('a[href^="tel:"]')) {
        n++;
        if (a.scrollWidth > a.clientWidth + 1) clipped++;
        const m = a.parentElement.querySelector('a[aria-label$="を地図で開く"]');
        if (m.getBoundingClientRect().top > a.getBoundingClientRect().bottom - 2) wrapped++;
      }
      const reset = [...document.querySelectorAll("button")].find((b) => b.textContent.includes("最初から"));
      // 「最初から」の文字が何行に分かれて描かれているか（文字の上端の位置の種類で数える）
      let resetLines = 0;
      if (reset) {
        const range = document.createRange();
        range.selectNodeContents(reset);
        resetLines = new Set([...range.getClientRects()].filter((q) => q.width > 0).map((q) => Math.round(q.top))).size;
      }
      return { n, clipped, wrapped, resetLines };
    });
    assert.ok(r.n > 10, "電話ボタンが表示されていない");
    assert.equal(r.clipped, 0, `幅${width}：番号が切れているボタンあり`);
    assert.equal(r.wrapped, 0, `幅${width}：地図ボタンが下の行に落ちている`);
    assert.ok(r.resetLines <= 1, `幅${width}：「最初から」が折り返している`);
    await ctx.close();
  }
});

// ---- 診療科（参考情報）----
test("開始画面の『診療科から探す（参考）』：神経内科を選ぶと該当施設が距離順に出て、注意書きがある", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "診療科から探す");
  await tap(page, "脳神経内科・神経内科");
  await page.waitForTimeout(400);
  const body = await page.innerText("body");
  assert.match(body, /救急の受入れ可否・夜間休日の対応・専門医の在院を示すものではありません/);
  assert.match(body, /脳神経内科・神経内科：\d+施設（現在地から距離順）/);
  assert.match(body, /実施基準の掲載リスト：/);
  assert.match(body, /大分赤十字病院/);
  assert.ok((await page.locator('a[href^="tel:"]').count()) > 3);
  await tap(page, "最初の画面に戻る");
  assert.match(await page.innerText("body"), /傷病者の区分を選択してください/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("結果画面の『診療科で絞り込む（参考）』：神経内科で絞ると件数が減り、指定なしで元に戻る", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "成人一般");
  await tap(page, "いいえ");
  await tap(page, "この内容で判定する");
  await tap(page, "脳卒中の疑い");
  await tap(page, "3.5時間以内");
  await page.waitForTimeout(600);
  const count = async () => Number((await page.innerText("body")).match(/表示(\d+)施設/)[1]);
  const before = await count();
  await tap(page, "脳神経内科・神経内科");
  const after = await count();
  assert.ok(after > 0 && after < before, `絞り込み前${before}・後${after}`);
  assert.match(await page.innerText("body"), /届出の診療科（標榜科）での絞り込みです/);
  await tap(page, "指定なし");
  assert.equal(await count(), before);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("診療科から探す：産婦人科で大分医療圏を選ぶと、妊産褥婦リスト（医療圏『全県』）の大分市の診療所も出る", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "診療科から探す");
  await tap(page, "産婦人科・産科・婦人科");
  await page.waitForTimeout(400);
  const body = await page.innerText("body");
  for (const n of ["堀永産婦人科医院", "みやむらレディースクリニック"]) assert.ok(body.includes(n), `${n} が出ない`);
  assert.deepEqual(errors, []);
  await ctx.close();
});

// ---- 開きっぱなしでも古くならない（v1.7.1）----
test("開きっぱなし：開いたのが平日昼でも、夜に結果を出すと『平日・夜間』で判定される", async () => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.clock.install({ time: new Date("2026-10-14T10:00:00+09:00") }); // 水曜10時
  await page.goto("file://" + FILE);
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  assert.match(await page.innerText("body"), /通常診療時間内/);
  await tap(page, "最初から");
  await page.clock.fastForward("10:00:00"); // 20時まで開きっぱなし
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  const body = await page.innerText("body");
  assert.match(body, /平日・診療時間外（夜間）/);
  assert.match(body, /20:0\d/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("開きっぱなし：移動してから結果を出すと、移動先の現在地で医療圏・距離が決まる", async () => {
  const { page, errors, ctx } = await openApp(); // 大分市役所付近で開く
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(600);
  const blue = async (t) => page.locator("button", { hasText: t }).first().evaluate((el) => getComputedStyle(el).backgroundColor);
  assert.equal(await blue("別杵速見"), "rgb(242, 242, 239)");
  await ctx.setGeolocation({ latitude: 33.3726, longitude: 131.5326 }); // 日出町へ移動
  await tap(page, "最初から");
  await tap(page, "精神疾患");
  await tap(page, "外見・バイタルサインによる重症");
  await page.waitForTimeout(800);
  assert.equal(await blue("別杵速見"), "rgb(17, 85, 204)", "移動先の医療圏が選ばれていない");
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("診療科の絞り込みは、戻って別の判定をすると解除される", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "成人一般");
  await tap(page, "いいえ");
  await tap(page, "この内容で判定する");
  await tap(page, "脳卒中の疑い");
  await tap(page, "3.5時間以内");
  await page.waitForTimeout(500);
  await tap(page, "脳神経内科・神経内科");
  assert.match(await page.innerText("body"), /届出の診療科（標榜科）での絞り込みです/);
  await page.locator("button", { hasText: "← 戻る" }).first().click();
  await page.waitForTimeout(200);
  await tap(page, "3.5時間超");
  await page.waitForTimeout(500);
  const body = await page.innerText("body");
  assert.doesNotMatch(body, /届出の診療科（標榜科）での絞り込みです/);
  assert.equal(await page.locator("button", { hasText: "指定なし" }).first().evaluate((el) => getComputedStyle(el).backgroundColor), "rgb(122, 63, 160)");
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("開始画面に傷病者の区分の定義（実施基準P2）が出る", async () => {
  const { page, errors, ctx } = await openApp();
  const body = await page.innerText("body");
  assert.match(body, /自宅（車中）分娩における新生児を除く/);
  assert.match(body, /妊娠中～産後１ヶ月健診受診前の者。自宅（車中）分娩における新生児を含む/);
  assert.match(body, /妊産褥婦の外傷・熱傷・中毒もこちら/);
  await tap(page, "疾病：妊産褥婦"); // 定義文があってもボタンとして押せる
  assert.match(await page.innerText("body"), /心肺停止/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("小児カード：『感ぜず』を選ぶと心肺停止の案内が出て、押すと心肺停止の結果になる（実施基準P18）", async () => {
  const { page, errors, ctx } = await openApp();
  await tap(page, "疾病：小児");
  await tap(page, "いいえ");
  await tap(page, "いいえ（疾病）");
  assert.doesNotMatch(await page.innerText("body"), /心肺停止として進む/);
  await page.locator('button[title="感ぜず"]').click();
  await page.waitForTimeout(150);
  assert.match(await page.innerText("body"), /呼吸を感じない・脈拍を触れない/);
  await tap(page, "心肺停止として進む");
  await page.waitForTimeout(300);
  assert.match(await page.innerText("body"), /心肺停止：直近の対応可能な救急医療機関等へ/);
  assert.deepEqual(errors, []);
  await ctx.close();
});
